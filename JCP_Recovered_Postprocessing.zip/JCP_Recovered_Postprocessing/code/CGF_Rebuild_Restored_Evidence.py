"""Recompute restored static-interface summaries and figures from packaged CSVs.
Run in Spyder or Python. No PDE solves, tuning, or external data downloads.
Dependencies: numpy, pandas, scipy, matplotlib. Paths are relative to this file.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import wilcoxon
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'analysis';OUT.mkdir(exist_ok=True)
FIG=ROOT/'figures';FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
allpairs=[];summary=[];ablation=[];counts=[]
for cfg in ['Training','Holdout']:
 p=ROOT/'evidence'/cfg.lower()
 d=pd.read_csv(p/'campaign_allocation_metrics.csv')
 h=d[d.allocation_family=='HALTON'].set_index(['seed','budget'])
 g=d[d.allocation_family=='GHG_PROTECTED'].set_index(['seed','budget'])
 for metric,short in [('full_rmse','full'),('interface_collar_rmse','collar')]:
  r=g[metric]/h[metric]
  for (seed,budget),v in r.items():allpairs.append(dict(configuration=cfg,metric=short,seed=seed,budget=budget,ratio=v))
  for n in [None,120,180,260,360]:
   hh=h if n is None else h.xs(n,level='budget');gg=g if n is None else g.xs(n,level='budget')
   ratio=gg[metric]/hh[metric]
   summary.append(dict(configuration=cfg,budget='all' if n is None else n,metric=metric,halton_median=hh[metric].median(),ghg_median=gg[metric].median(),paired_median=ratio.median(),wins=int((ratio<1).sum()),p_pooled=wilcoxon(gg[metric]-hh[metric],alternative='less').pvalue))
 a=pd.read_csv(p/'campaign_ablation_metrics.csv')
 for fam,rows in a.groupby('allocation_family'):
  if fam in ['HALTON','GHG_PROTECTED']:continue
  ablation.append(dict(configuration=cfg,family=fam,full_median=rows.full_rmse_ratio_to_protected.median(),full_mean=rows.full_rmse_ratio_to_protected.mean(),collar_median=rows.interface_collar_rmse_ratio_to_protected.median(),collar_mean=rows.interface_collar_rmse_ratio_to_protected.mean()))
 ga=pd.read_csv(p/'campaign_gate_matrix.csv');ga=ga[ga.transmission.notna()]
 for (fam,tr,gate),rows in ga.groupby(['allocation_family','transmission','gate']):counts.append(dict(configuration=cfg,family=fam,transmission=tr,gate=gate,passes=int(rows.passed.sum()),rows=len(rows)))
pairs=pd.DataFrame(allpairs);pairs.to_csv(OUT/'restored_static_pairs_long.csv',index=False)
pd.DataFrame(summary).to_csv(OUT/'restored_static_summary.csv',index=False)
pd.DataFrame(ablation).to_csv(OUT/'restored_ablations.csv',index=False)
pd.DataFrame(counts).to_csv(OUT/'restored_transmission_counts.csv',index=False)
fig,axs=plt.subplots(2,2,figsize=(10,6),layout='constrained')
for row,cfg in enumerate(['Training','Holdout']):
 for col,metric in enumerate(['full','collar']):
  ax=axs[row,col];d=pairs[(pairs.configuration==cfg)&(pairs.metric==metric)]
  for i,n in enumerate([120,180,260,360]):
   v=d[d.budget==n].sort_values('seed').ratio.to_numpy();ax.scatter(i+np.linspace(-.12,.12,len(v)),v,s=22,color='#527d98',alpha=.65)
   ax.scatter(i,np.median(v),s=60,marker='D',color='#163954',zorder=5)
  ax.axhline(1,color='#b15d38',ls='--',lw=1);ax.set_yscale('log');ax.set_xticks(range(4),[120,180,260,360]);ax.set_title(cfg+' | '+('Full field' if metric=='full' else 'Interface collar'));ax.set_ylabel('GHG error / Halton error');ax.set_xlabel('Interior-node budget');ax.grid(axis='y',alpha=.18)
fig.savefig(FIG/'fig11_restored_static_pairs.pdf');plt.close(fig)
q=pd.read_csv(ROOT/'evidence/nonquadratic_campaign_metrics.csv');res=[]
for keys,g in q.groupby(['configuration','allocation','transmission']):
 res.append(dict(zip(['configuration','allocation','transmission'],keys),allocation_fail=int((~g.gate_allocation).sum()),assembly_fail=int((~g.gate_assembly).sum()),overlap_fail=int((~g.gate_allocation & ~g.gate_assembly).sum()),joint_pass=int(g.gate_all.sum())))
pd.DataFrame(res).to_csv(OUT/'nonquadratic_failure_intersections.csv',index=False)
print('Rebuilt summaries and restored static-interface figure. No simulation was run.')
