"""Rebuild three added manuscript figures from included summary evidence."""
from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
R=Path(__file__).resolve().parents[1];F=R/'figures';F.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':13,'pdf.fonttype':42})
a=pd.read_csv(R/'evidence/adaptive_assessment/paired_comparisons.csv')
fig,ax=plt.subplots(1,2,figsize=(10,4.2),sharey=True)
configs=[('S','TRAIN'),('S','TRANSFER'),('Q','TRAIN'),('Q','TRANSFER')]
for j,(metric,title) in enumerate([('full_rmse','Full-field error ratio'),('wall_primary_solution_seconds','Required solution-time ratio')]):
 for ref,color,offset in [('HALTON','#24638b',-.10),('ADAPT_RESIDUAL','#b85d22',.10)]:
  vals=[]
  for family,config in configs:vals.append(float(a[(a.family==family)&(a.configuration==config)&(a.reference==ref)&(a.metric==metric)].geometric_ratio.iloc[0]))
  ax[j].scatter(vals,np.arange(4)+offset,label='GHG / '+('Halton' if ref=='HALTON' else 'residual-adaptive'),c=color,s=55)
 ax[j].axvline(1,color='black',ls='--',lw=.8);ax[j].set_xscale('log');ax[j].set_xlabel(title);ax[j].grid(axis='x',alpha=.2)
 from matplotlib.ticker import FixedLocator, FuncFormatter, NullLocator
 ax[j].xaxis.set_major_locator(FixedLocator([.25,.5,1,2] if j==0 else [.1,.2,.5,1,2,3]));ax[j].xaxis.set_major_formatter(FuncFormatter(lambda x,pos:f'{x:g}'));ax[j].xaxis.set_minor_locator(NullLocator())
ax[0].set_yticks(range(4),['Straight training','Straight transfer','Circular training','Circular transfer']);ax[0].invert_yaxis();ax[1].legend(fontsize=10,loc='lower right');fig.tight_layout();fig.savefig(F/'fig12_adaptive_comparison.pdf');plt.close(fig)
p=pd.read_csv(R/'analysis/green_adjoint/recomputed_pairs.csv')
problems=['GAUSSIAN_PREFLIGHT','S_TRAIN','S_FIXED_GEOMETRY_K30','NQ_TRAIN','Q_FIXED_GEOMETRY_K20']
labels=['Gaussian control','Straight K=100','Straight K=30','Circular K=50','Circular K=20']
columns=[('HALTON','J_abs_error'),('HALTON','full_rmse'),('HALTON','required_solution_seconds'),('ADJOINT','J_abs_error')]
vals=np.array([[p[(p.problem==q)&(p.target=='GHG_ADJOINT')&(p.reference==ref)&(p.metric==metric)].geometric_ratio.iloc[0] for ref,metric in columns] for q in problems])
fig,ax=plt.subplots(figsize=(9,4.3));im=ax.imshow(np.log2(vals),cmap='RdBu_r',norm=TwoSlopeNorm(vmin=-3,vcenter=0,vmax=3),aspect='auto')
for i in range(5):
 for j in range(4):ax.text(j,i,f'{vals[i,j]:.3f}',ha='center',va='center',color='white' if abs(np.log2(vals[i,j]))>1.6 else 'black',fontsize=12)
ax.set_xticks(range(4),['Objective error\n/ Halton','Full error\n/ Halton','Solution cost\n/ Halton','Objective error\n/ adjoint-only']);ax.set_yticks(range(5),labels);ax.set_title('GHG with adjoint influence: ratios below 1 favor the hybrid',pad=14)
cb=fig.colorbar(im,ax=ax,ticks=[-2,-1,0,1,2,3]);cb.ax.set_yticklabels(['0.25','0.5','1','2','4','8']);cb.set_label('Ratio (logarithmic color scale)');fig.tight_layout();fig.savefig(F/'fig13_adjoint_ratios.pdf');plt.close(fig)
d=pd.read_csv(R/'analysis/green_adjoint/recomputed_medians.csv')
colors={'HALTON':'#202020','FROZEN_GHG':'#2277aa','ADAPT_RESIDUAL':'#999999','DEFECT_ONLY':'#b58527','ADJOINT':'#32945a','GHG_ADJOINT':'#b73a3a'}
names={'HALTON':'Halton','FROZEN_GHG':'Frozen GHG','ADAPT_RESIDUAL':'Residual-adaptive','DEFECT_ONLY':'Defect only','ADJOINT':'Adjoint only','GHG_ADJOINT':'GHG + adjoint'}
fig,axs=plt.subplots(2,2,figsize=(10,8.2))
for ax,problem,title in zip(axs.flat,problems[1:],labels[1:]):
 for method in colors:
  z=d[(d.problem==problem)&(d.method==method)].sort_values('required_solution_seconds')
  ax.loglog(z.required_solution_seconds,z.J_abs_error,'.-',color=colors[method],label=names[method],ms=7)
 ax.set_title(title);ax.set_xlabel('Required solution seconds');ax.set_ylabel('Regional mean absolute error');ax.grid(alpha=.2)
handles,ls=axs[0,0].get_legend_handles_labels();fig.legend(handles,ls,loc='lower center',ncol=3,frameon=False,fontsize=11);fig.tight_layout(rect=(0,.09,1,1));fig.savefig(F/'fig14_adjoint_cost.pdf');plt.close(fig)
