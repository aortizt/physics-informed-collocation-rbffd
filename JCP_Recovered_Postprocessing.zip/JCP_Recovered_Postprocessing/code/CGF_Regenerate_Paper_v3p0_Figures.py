"""Regenerate all manuscript figures from the accompanying CSV/NPZ evidence.

Run this file from Spyder after extracting the complete v3.0 package.
No PDE simulation is performed. Original measured data are read unchanged.
"""
from pathlib import Path
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter, NullFormatter, FixedLocator, FuncFormatter
from PIL import Image

ROOT=Path(__file__).resolve().parent.parent
DATA=ROOT/'evidence'; OUT=ROOT/'figures'
OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.titlesize':12,'axes.labelsize':11,'legend.fontsize':9,'xtick.labelsize':10,'ytick.labelsize':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42,'savefig.dpi':300})
COLORS=['#2166ac','#b35806','#1b7837','#762a83','#878787']
FIGURES=[]
def save(fig,name,sources,caption,label,section):
    png_path=OUT/(name+'.png');pdf_path=OUT/(name+'.pdf')
    fig.savefig(png_path,bbox_inches='tight',dpi=300)
    if name in {'fig08_nonquadratic_validation','fig09_spe10_fields'}:
        # Raster PDF wrappers avoid backend transparency/image corruption seen
        # for these dense composite panels while preserving 300-dpi content.
        Image.open(png_path).convert('RGB').save(pdf_path,'PDF',resolution=300.0)
    else:
        fig.savefig(pdf_path,bbox_inches='tight')
        if not pdf_path.exists() or pdf_path.stat().st_size < 1024:
            Image.open(png_path).convert('RGB').save(pdf_path,'PDF',resolution=300.0)
    plt.close(fig)
    FIGURES.append(dict(number=len(FIGURES)+1,file_pdf='figures/'+name+'.pdf',file_png='figures/'+name+'.png',label=label,section=section,source_files=sources,caption=caption,generator='code/CGF_Regenerate_Paper_v3p0_Figures.py'))
def ratio_frame(d,a,b,metric):
    x=d[d.method==a].merge(d[d.method==b],on=['seed','budget'],suffixes=('_a','_b'),validate='one_to_one')
    return x[metric+'_a']/x[metric+'_b']

collar=pd.read_csv(DATA/'collar/campaign_metrics.csv')
configs=[('S_TRAIN_XI050_K1_100','Training'),('S_HOLDOUT_XI037_K1_30','Holdout')]
methods=['PROTECTED_NEAR_INTERFACE_SHEET','PROTECTED_FINITE_COLLAR_HALTON','PROTECTED_FINITE_COLLAR_RANDOM','PROTECTED_GHG_EQUAL']
labels=['Narrow band','Finite collar, Halton','Finite collar, random','Balanced GHG']
fig,axs=plt.subplots(2,2,figsize=(10.4,6.5),layout='constrained')
for row,(problem,title) in enumerate(configs):
    d=collar[collar.problem==problem]
    for col,(metric,mtitle) in enumerate([('full_rmse','Full field'),('collar_rmse','Evaluation collar')]):
        ax=axs[row,col]
        for i,(m,lab) in enumerate(zip(methods,labels)):
            ratios=ratio_frame(d,m,'HALTON',metric).to_numpy()
            ax.scatter(ratios,i+np.linspace(-.13,.13,len(ratios)),s=14,alpha=.55,color=COLORS[i])
            ax.scatter(np.median(ratios),i,marker='D',s=47,color=COLORS[i],edgecolor='white',zorder=5)
        ax.axvline(1,color='#333333',ls='--',lw=1);ax.set_xscale('log');ax.set_yticks(range(4),labels if col==0 else []);ax.invert_yaxis()
        ax.xaxis.set_major_locator(FixedLocator([.25,.5,1,2,4]));ax.xaxis.set_major_formatter(FuncFormatter(lambda v,p:f'{v:g}'));ax.xaxis.set_minor_formatter(NullFormatter())
        ax.set_title(title+' | '+mtitle);ax.set_xlabel('Error / matched Halton error');ax.grid(axis='x',alpha=.18)
save(fig,'fig01_localization_tradeoff','evidence/collar/campaign_metrics.csv','Paired errors relative to Halton for the static-interface configurations. Each point is one seed--budget comparison; diamonds are medians. Concentration reduces collar error while its full-field effect depends on width and configuration.','fig:localization','5.1')

fig,axs=plt.subplots(1,2,figsize=(10.4,3.5),layout='constrained')
removals=['PROTECTED_GHG_NO_GREEN','PROTECTED_GHG_NO_GRADIENT','UNPROTECTED_GHG_EQUAL']
for col,(metric,title) in enumerate([('full_rmse','Full field'),('collar_rmse','Evaluation collar')]):
    ax=axs[col]
    for j,(problem,conf) in enumerate(configs):
        d=collar[collar.problem==problem]
        for i,m in enumerate(removals):
            ratios=ratio_frame(d,m,'PROTECTED_GHG_EQUAL',metric)
            ax.scatter(np.median(ratios),i+(j-.5)*.2,s=55,marker=['o','s'][j],color=COLORS[j],label=conf if i==0 else None)
            lo,hi=np.quantile(ratios,[.25,.75]);ax.plot([lo,hi],[i+(j-.5)*.2]*2,color=COLORS[j],lw=2)
    ax.axvline(1,color='#333333',ls='--',lw=1);ax.set_yticks(range(3),['Remove Green','Remove Gradient','Remove explicit skeleton'] if col==0 else []);ax.invert_yaxis();ax.set_xlabel('Error / balanced protected-GHG error');ax.set_title(title);ax.grid(axis='x',alpha=.2)
axs[1].legend(loc='lower right')
save(fig,'fig02_component_ablations','evidence/collar/campaign_metrics.csv','Component-removal ratios relative to balanced protected GHG. Symbols show medians and lines show interquartile ranges. The construction without an explicit skeleton retains a uniform density term and a Halton proposal.','fig:ablations','5.1')

fig,axs=plt.subplots(1,2,figsize=(10.4,4.1),layout='constrained')
families=['HALTON','EQUAL_AREA_STRATIFIED','RESIDUAL_ADAPTIVE','GHG_PROTECTED_CHALLENGER'];flabels=['Halton','Equal-area','Residual adaptive','Protected challenger']
for ax,key,title in zip(axs,['E','F'],['Smooth homogeneous control','Localized-layer control']):
    d=pd.read_csv(DATA/key/'campaign_allocation_metrics.csv')
    for i,family in enumerate(families):
        g=d[d.allocation_family==family].groupby('budget').full_rmse
        med=g.median();ax.plot(med.index,med.values,'o-',color=COLORS[i],label=flabels[i],lw=1.8,ms=4)
        ax.fill_between(med.index,g.min(),g.max(),alpha=.09,color=COLORS[i])
    ax.set_yscale('log');ax.set_xlabel('Interior nodes');ax.set_ylabel('Full-field RMSE');ax.set_xticks([120,180,260,360]);ax.set_title(title);ax.grid(alpha=.2)
axs[0].legend(loc='lower left')
save(fig,'fig03_smooth_controls','evidence/E/campaign_allocation_metrics.csv; evidence/F/campaign_allocation_metrics.csv','Median full-field error and five-seed ranges in the smooth controls. Equal-area stratification is effective in the homogeneous case; the residual-adaptive response does not improve the localized-layer case.','fig:controls','5.2')

xm=pd.read_csv(DATA/'xm/campaign_metrics.csv')
xlabels=['Halton','Coverage/gradient 1:1','Coverage/gradient 3:1','Balanced GHG','Green/coverage 1:1','Green-heavy']
xmethods=['HALTON','C1_COVERAGE_GRADIENT_EQUAL','C3_COVERAGE_HEAVY','GHG_EQUAL','GREEN_COVERAGE_EQUAL','GREEN_HEAVY']
fig,ax=plt.subplots(figsize=(8.8,3.8),layout='constrained')
problemorder=['X_TRAIN_ANGLE25_K1_50','X_HOLDOUT_ANGLE40_K1_20','M_TRAIN_CIRCLE_R024_K30_1','M_HOLDOUT_CIRCLE_R020_K15_1']
values=np.array([[int(xm[(xm.problem==p)&(xm.method==m)].gate_admissible.sum()) for p in problemorder] for m in xmethods])
ax.imshow(values,vmin=0,vmax=20,cmap='Blues',aspect='auto');ax.set_xticks(range(4),['Oblique: train','Oblique: holdout','Circle: train','Circle: holdout']);ax.set_yticks(range(6),xlabels)
for i in range(6):
    for j in range(4):ax.text(j,i,f'{values[i,j]}/20',ha='center',va='center',color='white' if values[i,j]>=15 else '#111111',fontsize=11)
ax.set_title('Admissibility under the recorded criteria (selection requires 18/20)')
save(fig,'fig04_transfer_admissibility','evidence/xm/campaign_metrics.csv','Admissible rows for the oblique-interface and circular-inclusion allocations. No oblique training candidate reaches 18/20. The circular fixture passes the algebraic criteria but its selected rule does not improve holdout accuracy.','fig:transfer','5.3')

v=pd.read_csv(DATA/'vug/branch_summary.csv')
branches=[(a,t) for a in ['HALTON','PROTECTED_GHG_EQUAL'] for t in ['SCALAR_ROBIN_8','DTN_GEOMETRIC','GHG_CONDITIONED_DTN']]
vlabels=['H | Scalar 8','H | Cross-side','H | Pilot-modulated','G | Scalar 8','G | Cross-side','G | Pilot-modulated']
fig,axs=plt.subplots(1,2,figsize=(10.4,4.2),layout='constrained')
for ax,problem,title in zip(axs,['V_TRAIN_CIRCLE_R024_K50_1','V_HOLDOUT_CIRCLE_R020_K20_1'],['Training','Holdout']):
    vals=np.array([v[(v.problem==problem)&(v.allocation==a)&(v.transmission==t)].iloc[0][['local_passes','physical_passes','assembly_passes','all_gate_passes']].to_numpy(dtype=int) for a,t in branches])
    ax.imshow(vals,cmap='Blues',vmin=0,vmax=20,aspect='auto')
    for i in range(6):
        for j in range(4):ax.text(j,i,str(vals[i,j]),ha='center',va='center',color='white' if vals[i,j]>12 else '#222222',fontsize=11)
    ax.set_xticks(range(4),['Local*','Physical','Assembly','Joint']);ax.set_yticks(range(6),vlabels if ax is axs[0] else []);ax.set_title(title+' | passages out of 20')
save(fig,'fig05_coupling_criteria','evidence/vug/branch_summary.csv','Recorded coupling-criterion counts for Halton (H) and protected GHG (G). Local* denotes the implemented finite-value, condition, and range screen; it does not include an independently archived local PDE-residual test.','fig:coupling-gates','5.4')

hist=pd.read_csv(DATA/'vug/campaign_history.csv')
fig,axs=plt.subplots(1,2,figsize=(10.4,3.8),layout='constrained')
for ax,problem,title in zip(axs,['V_TRAIN_CIRCLE_R024_K50_1','V_HOLDOUT_CIRCLE_R020_K20_1'],['Training','Holdout']):
    for i,(t,label) in enumerate(zip(['SCALAR_ROBIN_8','DTN_GEOMETRIC','GHG_CONDITIONED_DTN'],['Scalar Robin 8','Cross-side Robin','Pilot-modulated Robin'])):
        d=hist[(hist.problem==problem)&(hist.allocation=='PROTECTED_GHG_EQUAL')&(hist.transmission==t)].groupby('iteration').physical_mismatch
        med=d.median();ax.plot(med.index,med,color=COLORS[i],lw=2,label=label);ax.fill_between(med.index,d.min(),d.max(),color=COLORS[i],alpha=.1)
    ax.axhline(.005,color='#555555',ls=':',lw=1);ax.set_yscale('log');ax.set_xlabel('Jacobi sweep');ax.set_ylabel('Trace/flux mismatch');ax.set_title(title+' | protected GHG');ax.grid(alpha=.2)
axs[0].legend(loc='lower left')
save(fig,'fig06_physical_mismatch','evidence/vug/campaign_history.csv','Physical mismatch for protected-GHG allocation, with medians and seed--budget ranges. The dotted line is the recorded terminal threshold. Cross-side impedance scales improve this finite trajectory test; the curves are not operator-norm contraction bounds.','fig:physical','5.4')

patch=pd.read_csv(ROOT/'analysis/quadratic_patch_audit.csv')
fig,ax=plt.subplots(figsize=(8.6,3.5),layout='constrained')
x=np.arange(len(patch));ax.bar(x-.18,patch.nodal_rmse,width=.34,color=COLORS[0],label='Nodal RMSE');ax.bar(x+.18,patch.linear_reconstruction_full_rmse,width=.34,color=COLORS[1],label='Linear reconstruction RMSE');ax.set_yscale('log');ax.set_ylim(1e-16,1e-2);ax.set_xticks(x,['Train H','Train G','Holdout H','Holdout G']);ax.set_ylabel('Absolute RMSE');ax.set_title('Quadratic fixture: independent audit at N = 360, seed 11');ax.legend(loc='upper right');ax.grid(axis='y',alpha=.2)
save(fig,'fig07_quadratic_reproduction','analysis/quadratic_patch_audit.csv','Nodal and reconstructed errors in four independent monolithic replays of the circular fixture. Near-exact nodal reproduction and a visible interpolation error distinguish this verification problem from a nonpolynomial PDE-accuracy benchmark.','fig:patch','5.4')

nq=pd.read_csv(DATA/'nonquadratic/campaign_metrics.csv')
fig,axs=plt.subplots(2,2,figsize=(10.4,7.0),layout='constrained')
branches=[(a,t) for a in ['HALTON','PROTECTED_GHG_EQUAL'] for t in ['SCALAR_ROBIN_8','DTN_GEOMETRIC','GHG_CONDITIONED_DTN']]
branch_labels=['H | Scalar 8','H | Cross-side','H | Pilot-modulated','G | Scalar 8','G | Cross-side','G | Pilot-modulated']
for ax,configuration,title in zip(axs[0],['TRAIN','HOLDOUT'],['Nonquadratic training','Nonquadratic holdout (diagnostic)']):
    vals=[]
    for allocation,transmission in branches:
        d=nq[(nq.configuration==configuration)&(nq.allocation==allocation)&(nq.transmission==transmission)]
        vals.append([d.gate_local.sum(),d.gate_physical.sum(),d.gate_assembly.sum(),d.gate_all.sum()])
    vals=np.asarray(vals,dtype=int)
    ax.imshow(vals,cmap='Blues',vmin=0,vmax=20,aspect='auto')
    for i in range(6):
        for j in range(4):
            ax.text(j,i,str(vals[i,j]),ha='center',va='center',color='white' if vals[i,j]>12 else '#222222',fontsize=10)
    ax.set_xticks(range(4),['Local','Physical','Assembly','Joint'])
    ax.set_yticks(range(6),branch_labels if ax is axs[0,0] else [])
    ax.set_title(title+' | passages / 20')

ax=axs[1,0]
for i,(configuration,label) in enumerate([('TRAIN','Training'),('HOLDOUT','Holdout')]):
    d=nq[(nq.configuration==configuration)&(nq.transmission=='DTN_GEOMETRIC')]
    wide=d.pivot(index=['budget','seed'],columns='allocation',values='full_rmse')
    ratios=(wide.PROTECTED_GHG_EQUAL/wide.HALTON).rename('ratio').reset_index()
    for budget,g in ratios.groupby('budget'):
        jitter=np.linspace(-7,7,len(g))
        ax.scatter(np.full(len(g),budget)+jitter,g.ratio,s=18,alpha=.55,color=COLORS[i])
    med=ratios.groupby('budget').ratio.median()
    ax.plot(med.index,med,'D-',color=COLORS[i],lw=1.8,ms=5,label=label)
ax.axhline(1,color='#333333',ls='--',lw=1)
ax.set_xticks([120,180,260,360]);ax.set_xlabel('Interior-node budget');ax.set_ylabel('Protected GHG / Halton full RMSE')
ax.set_title('Cross-side transmission | paired allocation ratios');ax.legend();ax.grid(alpha=.2)

ax=axs[1,1]
for i,(transmission,label) in enumerate([('SCALAR_ROBIN_8','Scalar 8'),('DTN_GEOMETRIC','Cross-side'),('GHG_CONDITIONED_DTN','Pilot-modulated')]):
    paths=[]
    for case in (DATA/'nonquadratic/cases').glob('nq-holdout__protected-ghg-equal-*'):
        m=pd.read_json(case/'metrics.json',typ='series')
        if m['transmission']==transmission:
            h=pd.read_csv(case/'history.csv')[['iteration','physical_mismatch']]
            h['case']=case.name;paths.append(h)
    hist=pd.concat(paths,ignore_index=True)
    by=hist.groupby('iteration').physical_mismatch
    med=by.median();ax.plot(med.index,med,color=COLORS[i],lw=2,label=label)
    ax.fill_between(med.index,by.min(),by.max(),color=COLORS[i],alpha=.08)
ax.axhline(.005,color='#555555',ls=':',lw=1);ax.set_yscale('log');ax.set_xlabel('Jacobi sweep');ax.set_ylabel('Trace/flux mismatch')
ax.set_title('Nonquadratic holdout | protected GHG');ax.legend(loc='lower left');ax.grid(alpha=.2)
save(fig,'fig08_nonquadratic_validation','evidence/nonquadratic/campaign_metrics.csv; evidence/nonquadratic/cases/*/history.csv','Nonquadratic circular-interface stress test. Cross-side rules pass every local and physical screen, while conservation and two protected-cloud coverage failures keep all training branches below the predeclared 18/20 joint-selection threshold. Paired error ratios show a training advantage that is weaker on holdout; the mismatch trajectories separate scalar from cross-side transmission.','fig:nonquadratic','5.5')

fields=np.load(DATA/'P/interface_indicator_fields.npz');ref=np.load(DATA/'P/reference/reference_factor_4.npz')
fig,axs=plt.subplots(1,3,figsize=(10.4,4.8),layout='constrained')
for ax,z,title,cmap in zip(axs,[fields['log10_geometric_horizontal_k'],fields['jump_score'],ref['pressure_native']],['Horizontal permeability','Log-permeability jump','Reference pressure'],['viridis','magma','viridis']):
    im=ax.imshow(z,origin='lower',extent=[0,1200,0,2200],aspect='equal',cmap=cmap);ax.set_title(title);ax.set_xlabel('x (ft)');ax.set_ylabel('y (ft)');fig.colorbar(im,ax=ax,shrink=.75,pad=.03)
save(fig,'fig09_spe10_fields','evidence/P/interface_indicator_fields.npz; evidence/P/reference/reference_factor_4.npz','SPE10 Model-2 Layer-68 fields: log10 geometric horizontal permeability in mD, coefficient-jump score, and pressure from the finest finite-volume reference restricted to the native grid.','fig:spe-fields','5.6')

sp=pd.read_csv(DATA/'P/campaign_metrics.csv');methodnames=sp.method.unique();print('SPE10 methods:',methodnames)
h=[m for m in methodnames if 'HALTON' in m.upper() and 'PROTECTED' not in m.upper()][0]
g=[m for m in methodnames if 'PROTECTED' in m.upper()][0]
fv=[m for m in methodnames if 'STRUCTURED' in m.upper()][0]
fig,axs=plt.subplots(2,2,figsize=(10.4,6.5),layout='constrained')
for ax,metric,title,ylabel in [(axs[0,0],'pressure_rmse','Pressure accuracy','Pressure RMSE'),(axs[0,1],'flux_vector_rmse','Flux accuracy','Flux-vector RMSE'),(axs[1,0],'charged_total_seconds','Charged cost','Time (s)')]:
    for i,(m,label) in enumerate([(h,'Halton / P1 FEM'),(g,'Protected / P1 FEM'),(fv,'Structured FV')]):
        by=sp[sp.method==m].groupby('interior_budget')[metric];med=by.median();ax.plot(med.index,med,'o-',color=COLORS[i],label=label,ms=4)
        ax.fill_between(med.index,by.min(),by.max(),color=COLORS[i],alpha=.1)
    ax.set_xscale('log');ax.set_yscale('log');ax.set_xticks([600,1200,2400,4800]);ax.xaxis.set_major_formatter(ScalarFormatter());ax.xaxis.set_minor_formatter(NullFormatter());ax.set_xlabel('Interior-node budget');ax.set_ylabel(ylabel);ax.set_title(title);ax.grid(alpha=.2)
axs[0,0].legend()
joined=sp[sp.method==g].merge(sp[sp.method==h],on=['interior_budget','seed'],suffixes=('_g','_h'))
for i,(metric,label) in enumerate([('pressure_rmse','Pressure'),('flux_vector_rmse','Flux')]):
    j=joined.assign(ratio=joined[metric+'_g']/joined[metric+'_h']);s=j.groupby('interior_budget').ratio
    axs[1,1].plot(s.median().index,s.median(),'o-',color=COLORS[i],label=label);axs[1,1].fill_between(s.median().index,s.min(),s.max(),color=COLORS[i],alpha=.1)
axs[1,1].axhline(1,color='#333333',ls='--');axs[1,1].set_xscale('log');axs[1,1].set_xticks([600,1200,2400,4800]);axs[1,1].xaxis.set_major_formatter(ScalarFormatter());axs[1,1].xaxis.set_minor_formatter(NullFormatter());axs[1,1].set_xlabel('Interior-node budget');axs[1,1].set_ylabel('Protected / Halton error');axs[1,1].set_title('Paired accuracy ratios');axs[1,1].legend();axs[1,1].grid(alpha=.2)
save(fig,'fig10_spe10_performance','evidence/P/campaign_metrics.csv','SPE10 accuracy, charged time, and paired allocation ratios. Lines show medians and shading shows five-seed ranges. Both scattered-point methods use P1 finite elements; FV is the structured upscaled control.','fig:spe-performance','5.6')
import json
(ROOT/'analysis/figure_inventory.json').write_text(json.dumps(FIGURES,indent=2))
print('Generated',len(FIGURES),'figures in PDF and PNG.')
