"""Reanalyse extracted production archive, without rerunning or selecting iterates.
Usage: python CGF_Audit_Adaptive_Production.py EXTRACTED_DIRECTORY OUTPUT_DIRECTORY
Requires numpy and pandas. Original archive remains unchanged.
"""
import sys,json,hashlib,itertools
from pathlib import Path
import numpy as np
import pandas as pd

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main(root,out):
    out.mkdir(parents=True,exist_ok=True)
    d=pd.read_csv(root/'campaign_metrics.csv'); issues=[]
    manifest=pd.read_csv(root/'scientific_manifest_sha256.csv')
    for r in manifest.itertuples():
        p=root/r.relative_path
        if not p.is_file() or sha(p)!=r.sha256 or p.stat().st_size!=r.bytes: issues.append(str(p))
    protocol=json.loads((root/'protocol.json').read_text()); ph=protocol.pop('protocol_hash')
    assert hashlib.sha256(json.dumps(protocol,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()==ph
    keys=['family','configuration','method','budget','seed']; indexed=d.set_index(keys)
    assert indexed.index.is_unique
    checked=0
    for folder in (root/'cases').iterdir():
        m=json.loads((folder/'metrics.json').read_text()); c=json.loads((folder/'commit.json').read_text())
        assert sha(folder/'metrics.json')==c['metrics_sha256'] and c['protocol_hash']==ph==m['protocol_hash']
        for name,h in m['payload_sha256'].items(): assert sha(folder/name)==h
        row=indexed.loc[tuple(m[k] for k in keys)]
        for k,v in m.items():
            if k not in row or isinstance(v,(dict,list)):continue
            if isinstance(v,(float,int)) and not isinstance(v,bool): assert np.isclose(row[k],v,rtol=1e-12,atol=1e-14,equal_nan=True),(folder,k)
            elif v is not None: assert row[k]==v,(folder,k)
        checked+=1
    assert checked==len(d)==400 and not issues
    assert (d.groupby(keys[:3]).size()==20).all()
    assert set(d.budget)=={120,180,260,360}
    assert (d.wall_primary_solution_seconds<=d.wall_primary_audited_seconds).all()
    assert (d.pilot_seconds<=d.wall_primary_solution_seconds).all()
    gates=['valid_solve','screen_local','screen_conservation','screen_accuracy','screen_joint']
    d.groupby(keys[:3])[gates].sum().to_csv(out/'acceptance_counts.csv')
    metrics=['full_rmse','collar_rmse','wall_primary_solution_seconds','wall_primary_audited_seconds']
    pairs=[]
    for (fam,conf),g in d.groupby(['family','configuration']):
        a=g[g.method=='FROZEN_GHG'].set_index(['seed','budget'])
        for ref in ['HALTON','ADAPT_RESIDUAL','ADAPT_VARIATION','QUASI_UNIFORM']:
            b=g[g.method==ref].set_index(['seed','budget'])
            for metric in metrics:
                lr=np.log(a[metric]/b[metric]); blocks=lr.groupby('seed').mean()
                null=[np.mean(blocks.values*np.array(s)) for s in itertools.product([-1,1],repeat=len(blocks))]
                pairs.append(dict(family=fam,configuration=conf,reference=ref,metric=metric,geometric_ratio=float(np.exp(blocks.mean())),paired_wins=int((lr<0).sum()),paired_total=len(lr),seed_blocks=len(blocks),exploratory_one_sided_p=float(np.mean(np.array(null)<=blocks.mean()+1e-14))))
    pd.DataFrame(pairs).to_csv(out/'paired_comparisons.csv',index=False)
    med=d.groupby(['family','configuration','method','budget'])[metrics].median().reset_index()
    med.to_csv(out/'budget_medians.csv',index=False)
    envelope=[]
    for (fam,conf),g in med.groupby(['family','configuration']):
        for _,a in g[g.method=='FROZEN_GHG'].iterrows():
            for ref in ['HALTON','ADAPT_RESIDUAL']:
                eligible=g[(g.method==ref)&(g.wall_primary_solution_seconds<=a.wall_primary_solution_seconds)]
                for metric in ['full_rmse','collar_rmse']:
                    if len(eligible):
                        b=eligible.loc[eligible[metric].idxmin()]
                        envelope.append(dict(family=fam,configuration=conf,ghg_budget=int(a.budget),reference=ref,metric=metric,reference_budget=int(b.budget),ghg_error=a[metric],reference_error=b[metric],ghg_ratio=a[metric]/b[metric]))
    pd.DataFrame(envelope).to_csv(out/'measured_cost_envelope.csv',index=False)
    audit=dict(rows=len(d),cases_verified=checked,manifest_files_verified=len(manifest),manifest_mismatches=issues,protocol_hash=ph,source_sha256={p.name:sha(p) for p in (root/'source').glob('*.py')},completed=int((d.status=='completed').sum()),joint_screen_passes=int(d.screen_joint.sum()),method_solves=int(d.number_of_solves.sum()),secondary_robin_cases=int(d.robin_screen_joint.notna().sum()))
    (out/'audit.json').write_text(json.dumps(audit,indent=2)+'\n')
    print(json.dumps(audit,indent=2));print(pd.DataFrame(pairs).query("reference=='HALTON'").to_string(index=False));print(pd.DataFrame(envelope).to_string(index=False))
if __name__=='__main__':main(Path(sys.argv[1]),Path(sys.argv[2]))
