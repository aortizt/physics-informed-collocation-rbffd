"""Audit and summarize the frozen nonquadratic production campaign."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import binomtest, wilcoxon


PKG = Path(__file__).resolve().parents[1]
DATA = PKG / "evidence" / "nonquadratic"
OUT = PKG / "analysis"
OUT.mkdir(parents=True, exist_ok=True)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


metrics = pd.read_csv(DATA / "campaign_metrics.csv")
manifest = pd.read_csv(DATA / "scientific_manifest_sha256.csv")
audit_rows = []
for row in manifest.itertuples(index=False):
    path = DATA / row.relative_path
    audit_rows.append(
        {
            "relative_path": row.relative_path,
            "exists": path.is_file(),
            "bytes_expected": int(row.bytes),
            "bytes_actual": path.stat().st_size if path.is_file() else None,
            "sha256_expected": row.sha256,
            "sha256_actual": sha256(path) if path.is_file() else None,
        }
    )
audit = pd.DataFrame(audit_rows)
audit["pass"] = (
    audit["exists"]
    & (audit["bytes_expected"] == audit["bytes_actual"])
    & (audit["sha256_expected"] == audit["sha256_actual"])
)
audit.to_csv(OUT / "nonquadratic_archive_audit.csv", index=False)

with (DATA / "protocol.json").open() as handle:
    protocol = json.load(handle)
with (DATA / "production_complete.json").open() as handle:
    complete = json.load(handle)

summary = (
    metrics.groupby(["configuration", "allocation", "transmission"], sort=True)
    .agg(
        rows=("status", "size"),
        allocation_passes=("gate_allocation", "sum"),
        local_passes=("gate_local", "sum"),
        physical_passes=("gate_physical", "sum"),
        assembly_passes=("gate_assembly", "sum"),
        joint_passes=("gate_all", "sum"),
        median_full_rmse=("full_rmse", "median"),
        median_collar_rmse=("collar_rmse", "median"),
        median_nodal_rmse=("nodal_rmse", "median"),
        median_linear_full_rmse=("linear_full_rmse", "median"),
        median_independent_residual=("independent_residual_relative", "median"),
        median_conservation_defect=("conservation_defect", "median"),
        median_terminal_mismatch=("physical_mismatch_terminal", "median"),
        median_q_net=("q_net", "median"),
        median_q_tail=("q_tail", "median"),
        median_charged_seconds=("charged_total_seconds", "median"),
    )
    .reset_index()
)
summary.to_csv(OUT / "nonquadratic_branch_summary_extended.csv", index=False)

paired_rows = []
for transmission in ["DTN_GEOMETRIC", "GHG_CONDITIONED_DTN"]:
    for configuration in ["TRAIN", "HOLDOUT"]:
        group = metrics[
            (metrics["transmission"] == transmission)
            & (metrics["configuration"] == configuration)
        ]
        for metric in [
            "full_rmse",
            "collar_rmse",
            "nodal_rmse",
            "linear_full_rmse",
            "independent_residual_relative",
            "charged_total_seconds",
        ]:
            wide = group.pivot(
                index=["budget", "seed"], columns="allocation", values=metric
            )
            challenger = wide["PROTECTED_GHG_EQUAL"]
            primary = wide["HALTON"]
            ratio = challenger / primary
            try:
                signed_rank = float(
                    wilcoxon(challenger, primary, alternative="less").pvalue
                )
            except ValueError:
                signed_rank = np.nan
            paired_rows.append(
                {
                    "configuration": configuration,
                    "transmission": transmission,
                    "metric": metric,
                    "pairs": len(ratio),
                    "challenger_wins": int((ratio < 1).sum()),
                    "median_ratio": float(ratio.median()),
                    "q1_ratio": float(ratio.quantile(0.25)),
                    "q3_ratio": float(ratio.quantile(0.75)),
                    "wilcoxon_one_sided_p": signed_rank,
                    "sign_test_one_sided_p": float(
                        binomtest(int((ratio < 1).sum()), len(ratio), 0.5,
                                  alternative="greater").pvalue
                    ),
                }
            )
pd.DataFrame(paired_rows).to_csv(
    OUT / "nonquadratic_paired_statistics.csv", index=False
)

# Attribute failed assembly gates to the continuous predeclared components.
gates = protocol["gates"]
failure_rows = []
for key, group in metrics.groupby(
    ["configuration", "allocation", "transmission"], sort=True
):
    failure_rows.append(
        {
            "configuration": key[0],
            "allocation": key[1],
            "transmission": key[2],
            "rows": len(group),
            "conservation_failures": int(
                (group["conservation_defect"] > gates["conservation_max"]).sum()
            ),
            "full_relative_l2_failures": int(
                (group["full_relative_l2"] > gates["full_relative_l2_max"]).sum()
            ),
            "monolithic_full_factor_failures": int(
                (
                    group["full_rmse"]
                    > gates["monolithic_error_factor"]
                    * group["monolithic_full_rmse"]
                ).sum()
            ),
            "monolithic_collar_factor_failures": int(
                (
                    group["collar_rmse"]
                    > gates["monolithic_error_factor"]
                    * group["monolithic_collar_rmse"]
                ).sum()
            ),
            "range_failures": int(
                (group["range_violation"] > gates["range_violation_max"]).sum()
            ),
            "assembly_failures": int((~group["gate_assembly"]).sum()),
        }
    )
pd.DataFrame(failure_rows).to_csv(
    OUT / "nonquadratic_gate_failure_attribution.csv", index=False
)

# Median log-log error slopes and empirical charged-cost slopes by branch.
slope_rows = []
for key, group in metrics.groupby(
    ["configuration", "allocation", "transmission"], sort=True
):
    by_budget = group.groupby("budget").median(numeric_only=True)
    for metric in ["full_rmse", "collar_rmse", "nodal_rmse",
                   "independent_residual_relative", "charged_total_seconds"]:
        slope = np.polyfit(
            np.log(by_budget.index.to_numpy(dtype=float)),
            np.log(by_budget[metric].to_numpy(dtype=float)),
            1,
        )[0]
        slope_rows.append(
            {
                "configuration": key[0],
                "allocation": key[1],
                "transmission": key[2],
                "metric": metric,
                "log_log_slope": float(slope),
            }
        )
pd.DataFrame(slope_rows).to_csv(
    OUT / "nonquadratic_empirical_scaling.csv", index=False
)

state_files = list((DATA / "cases").glob("*/states.npz"))
actual_state_hashes = {sha256(path) for path in state_files}
declared_state_hashes = set(metrics["state_sha256"].dropna().astype(str))

report = {
    "manifest_rows": int(len(audit)),
    "manifest_passes": int(audit["pass"].sum()),
    "manifest_all_pass": bool(audit["pass"].all()),
    "campaign_rows": int(len(metrics)),
    "campaign_status_counts": metrics["status"].value_counts().to_dict(),
    "protocol_hash": protocol["protocol_hash"],
    "production_protocol_hash": complete.get("protocol_hash"),
    "protocol_hash_match": protocol["protocol_hash"]
    == complete.get("protocol_hash"),
    "state_files": len(state_files),
    "declared_state_hashes": len(declared_state_hashes),
    "state_hashes_match_metrics": actual_state_hashes == declared_state_hashes,
}
(OUT / "nonquadratic_audit_summary.json").write_text(
    json.dumps(report, indent=2), encoding="utf-8"
)
print(json.dumps(report, indent=2))
