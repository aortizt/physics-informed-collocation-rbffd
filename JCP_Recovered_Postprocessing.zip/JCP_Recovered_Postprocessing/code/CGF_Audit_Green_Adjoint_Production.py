"""Read-only production audit and recomputation. No PDE campaign is rerun.
Usage: python CGF_Audit_Green_Adjoint_Production.py RESULTS_DIR OUTPUT_DIR
Requires NumPy, pandas, SciPy. Outputs an audit plus comparisons and counts.
"""
from pathlib import Path
import json,hashlib,argparse
import numpy as np
import pandas as pd
from scipy.sparse import csc_matrix

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main(root,out):
 root=Path(root);out=Path(out);out.mkdir(parents=True,exist_ok=True)
 protocol=json.loads((root/'protocol.json').read_text());pid=hashlib.sha256(json.dumps(protocol['contract'],sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
 assert pid==protocol['id'],'Protocol mismatch'
 manifest=pd.read_csv(root/'scientific_manifest_sha256.csv');bad=[]
 for _,r in manifest.iterrows():
  p=root/r.relative_path
  if not p.is_file() or p.stat().st_size!=r.bytes or digest(p)!=r.sha256:bad.append(str(p))
 assert not bad,('Manifest mismatch',bad)
 for name,h in protocol['contract']['sources'].items():assert digest(root/'sources'/name)==h,name
 df=pd.read_csv(root/'campaign.csv');checks=[];commits=0;fielddiff=0.
 assert len(df)==300 and not df.duplicated(['problem','method','interior_budget','seed']).any()
 rows=[]
 for folder in sorted((root/'cases').iterdir()):
  commit=json.loads((folder/'commit.json').read_text());assert commit['protocol']==pid
  for name,h in commit['hashes'].items():assert digest(folder/name)==h,str(folder/name)
  d=json.loads((folder/'metrics.json').read_text());rows.append(d);commits+=1
  csv=df[(df.problem==d['problem'])&(df.method==d['method'])&(df.interior_budget==d['interior_budget'])&(df.seed==d['seed'])]
  assert len(csv)==1
  for key,val in d.items():
   saved=csv.iloc[0][key]
   if isinstance(val,(int,float)) and not isinstance(val,bool):assert np.isclose(saved,val,rtol=1e-10,atol=1e-14),key
   else:assert saved==val,key
  with np.load(folder/'state.npz',allow_pickle=False) as z:
   rmse=np.sqrt(np.mean((z['evaluation_phs']-z['evaluation_exact'])**2))
   fielddiff=max(fielddiff,abs(rmse-d['full_rmse']));assert np.isclose(rmse,d['full_rmse'],rtol=1e-12)
   if d['method'] in ('ADJOINT','GHG_ADJOINT'):
    A=csc_matrix((z['enriched_matrix_data'],z['enriched_matrix_indices'],z['enriched_matrix_indptr']),shape=tuple(z['enriched_matrix_shape']))
    r=z['enriched_rhs']-A@z['transferred_pilot'];adj=z['adjoint'];j=z['objective_vector']
    ar=np.linalg.norm(A.T@adj-j)/max(np.linalg.norm(j),1e-15)
    dr=np.linalg.norm(r-z['scaled_defect'])/max(np.linalg.norm(r),1e-15)
    est=float(adj@r)
    assert ar<1e-8 and dr<1e-10
    assert np.isclose(est,d['signed_defect_estimate'],rtol=1e-9,atol=1e-13)
    checks.append(dict(case=folder.name,adjoint_residual=ar,defect_reconstruction=dr))
 assert commits==len(df)
 pd.DataFrame(checks).to_csv(out/'saved_adjoint_checks.csv',index=False)
 audit=dict(cases_verified=commits,manifest_files_verified=len(manifest),manifest_mismatches=bad,protocol_hash=pid,
  source_sha256=protocol['contract']['sources'],valid_solves=int(df.valid_solve.sum()),joint_passes=int(df.screen_joint.sum()),
  objective_quadrature_passes=int(df.screen_objective_quadrature.sum()),supplement_passes=int(df.screen_supplement.sum()),
  saved_adjoint_checks=len(checks),maximum_adjoint_residual=max(x['adjoint_residual'] for x in checks),maximum_field_rmse_difference=fielddiff)
 (out/'audit.json').write_text(json.dumps(audit,indent=2))
 # Matched budgets only. Preserve failed scientific screens.
 matched=df[df.interior_budget<=360]
 counts=matched.groupby(['problem','method'])[['valid_solve','screen_local','screen_accuracy','screen_conservation','screen_joint','screen_objective_quadrature']].agg(['sum','count'])
 counts.to_csv(out/'matched_acceptance.csv')
 pairs=[]
 for target,reference in [('GHG_ADJOINT',x) for x in ('HALTON','FROZEN_GHG','ADAPT_RESIDUAL','DEFECT_ONLY','ADJOINT')]+[('ADJOINT','DEFECT_ONLY'),('ADJOINT','HALTON'),('FROZEN_GHG','HALTON')]:
  m=matched[matched.method==target].merge(matched[matched.method==reference],on=['problem','interior_budget','seed'],suffixes=('_a','_b'))
  for problem,g in m.groupby('problem'):
   for metric in ('J_abs_error','full_rmse','collar_rmse','required_solution_seconds'):
    ratio=g[metric+'_a']/g[metric+'_b'].clip(lower=1e-15)
    logs=np.log(ratio.clip(lower=1e-15)).groupby(g.seed).mean()
    pairs.append(dict(problem=problem,target=target,reference=reference,metric=metric,geometric_ratio=np.exp(logs.mean()),seed_blocks=len(logs),pairs=len(g),wins=int((ratio<1).sum())))
 pd.DataFrame(pairs).to_csv(out/'recomputed_pairs.csv',index=False)
 med=df.groupby(['problem','method','interior_budget'])[['J_abs_error','full_rmse','collar_rmse','required_solution_seconds']].median().reset_index()
 med.to_csv(out/'recomputed_medians.csv',index=False)
 envelope=[]
 for target in ('GHG_ADJOINT','FROZEN_GHG','ADJOINT'):
  for _,a in med[med.method==target].iterrows():
   candidates=med[(med.problem==a.problem)&(med.method=='HALTON')&(med.required_solution_seconds<=a.required_solution_seconds)]
   for metric in ('J_abs_error','full_rmse'):
    if len(candidates):
     r=candidates.loc[candidates[metric].idxmin()]
     envelope.append(dict(problem=a.problem,target=target,budget=a.interior_budget,metric=metric,target_error=a[metric],halton_budget=r.interior_budget,halton_error=r[metric],ratio=a[metric]/max(r[metric],1e-15)))
 pd.DataFrame(envelope).to_csv(out/'recomputed_halton_cost_envelope.csv',index=False)
 print(json.dumps(audit,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('results');p.add_argument('output');a=p.parse_args();main(a.results,a.output)
