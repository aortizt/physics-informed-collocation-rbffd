"""Protocol fixed before testing fresh seeds and reserved geometries.
Run the numbered scripts with F5; do not edit thresholds to obtain a pass.
"""
from pathlib import Path
HERE=Path(__file__).resolve().parent
OUTPUT_ROOT=HERE/'CGF_Frozen_Validation_v1_outputs'
ARMS=['square25','ls_flux','ls_pde','ls_both']
SEEDS=[53,71,89]
FOUNDATION_BUDGETS=[120,240,480]
TRANSFER_BUDGET=480
LOADS=[0.,0.25]
EXTRA_PDE_PER_INTERIOR=2
EXTRA_INTERFACE_FACTOR=4
SOLVER_TOL=1e-8
CONSTRAINT_TOL=1e-10
DENSE_INTERFACE_POINTS=257
DENSE_FIELD_GRID=61
PHYSICAL_LIMITS=dict(interface_relative=.02,bulk_relative=.05,balance_scaled=.05,
                     flux_jump_relative=.05,quadrature_change_scaled=.005)

