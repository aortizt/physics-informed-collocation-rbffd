"""Frozen recovery formulations. Only extension: explicit load propagation.
Weights, oversampling, constraints and stencil remain as in the recovery run.
"""
import numpy as np
from scipy.linalg import lstsq
from scipy.sparse import csr_matrix,diags,vstack
import validation_base_engine as E
import validation_settings as K

def interface_operator(m,points=64):
    n,t,c,lo,hi=E.geometry(m['case'])
    if points==64:
        x,w=np.polynomial.legendre.leggauss(64);s=(lo+hi)/2+(hi-lo)*x/2;w=w/2
    else:
        # Midpoints avoid endpoints and are distinct from collocation nodes.
        s=lo+(hi-lo)*(np.arange(points)+.5)/points;w=np.full(points,1/points)
    p=c+s[:,None]*t
    D0=E.operator(m,p,n,np.zeros(len(p),int))
    D1=m['case']['contrast']*E.operator(m,p,n,np.ones(len(p),int))
    ref=E.exact(p,m['case'],0)[1]@n
    return p,w,D0,D1,ref

def weighted_norm(x,w): return float(np.sqrt(w@(x*x)))

def reduced_constraints(m,load=0.):
    """u=g+T y enforces exterior Dirichlet data and nodal interface traces exactly."""
    kinds=m['kinds'];sides=m['sides'];n=len(kinds);g=np.zeros(n)
    boundary=np.flatnonzero(kinds=='boundary')
    for side in (0,1):
        ids=boundary[sides[boundary]==side]
        # Only prescribed boundary values, never interior exact values.
        g[ids]=E.exact(m['nodes'][ids],m['case'],side,load)[0]
    ids=list(np.flatnonzero(kinds=='pde'))
    left=np.flatnonzero((kinds=='interface')&(sides==0))
    right=np.flatnonzero((kinds=='interface')&(sides==1))
    rr=ids.copy();cc=list(range(len(ids)));offset=len(ids)
    for j,(a,b) in enumerate(zip(left,right)):
        rr.extend([int(a),int(b)]);cc.extend([offset+j,offset+j])
    T=csr_matrix((np.ones(len(rr)),(rr,cc)),shape=(n,len(ids)+len(left)))
    return g,T

def ls_solve(m,b,arm,seed,load=0.):
    """A declared constrained least-squares experiment, not a published-method replay.

    Use original row-scaled PDE and flux rows. Append independent evaluation
    equations, each scaled by its full-row l1 norm. Give left PDE, right PDE,
    and flux groups equal mean-square weight. Nodal traces and boundary values
    remain exact through variable elimination. Solve with dense SVD, not normal
    equations. The exact interior state is unavailable to this function.
    """
    kinds=m['kinds'];sides=m['sides'];case=m['case'];blocks=[];rhs=[]
    for side in (0,1):
        ids=np.flatnonzero((kinds=='pde')&(sides==side));B=m['A'][ids];bb=b[ids]
        if arm in ('ls_pde','ls_both'):
            pp=E.sample_side(K.EXTRA_PDE_PER_INTERIOR*len(ids),case,side,seed+50000+101*side)
            k=1. if side==0 else case['contrast']
            H=-k*E.operator(m,pp,'lap',np.full(len(pp),side))
            scale=1/np.asarray(abs(H).sum(axis=1)).ravel()
            H=diags(scale)@H;hb=scale*E.exact(pp,case,side,load)[2]
            B=vstack([B,H]).tocsr();bb=np.r_[bb,hb]
        blocks.append(B/np.sqrt(B.shape[0]));rhs.append(bb/np.sqrt(B.shape[0]))
    ids=np.flatnonzero((kinds=='interface')&(sides==1));B=m['A'][ids];bb=b[ids]
    if arm in ('ls_flux','ls_both'):
        n,t,c,lo,hi=E.geometry(case);count=K.EXTRA_INTERFACE_FACTOR*len(ids)
        ss=lo+(hi-lo)*(np.arange(count)+.5)/count;pp=c+ss[:,None]*t
        H=E.operator(m,pp,n,np.zeros(count,int))-case['contrast']*E.operator(m,pp,n,np.ones(count,int))
        scale=1/np.asarray(abs(H).sum(axis=1)).ravel()
        B=vstack([B,diags(scale)@H]).tocsr();bb=np.r_[bb,np.zeros(count)]
    blocks.append(B/np.sqrt(B.shape[0]));rhs.append(bb/np.sqrt(B.shape[0]))
    H=vstack(blocks).tocsr();f=np.concatenate(rhs);g,T=reduced_constraints(m,load)
    B=(H@T).toarray();y_rhs=f-H@g
    y,_,rank,s=lstsq(B,y_rhs,cond=None,lapack_driver='gelsd')
    v=g+T@y;res=B@y-y_rhs
    stationarity=float(np.linalg.norm(B.T@res)/max(s[0]*(s[0]*np.linalg.norm(y)+np.linalg.norm(y_rhs)),1e-300))
    left=np.flatnonzero((kinds=='interface')&(sides==0));right=ids
    boundary=np.flatnonzero(kinds=='boundary')
    constraint=float(max(np.max(np.abs(v[boundary]-g[boundary])),np.max(np.abs(v[left]-v[right]))))
    return v,dict(ls_equations=B.shape[0],ls_unknowns=B.shape[1],ls_rank=int(rank),
       ls_full_column_rank=bool(rank==B.shape[1]),ls_condition_2=float(s[0]/s[-1]),
       ls_stationarity_relative=stationarity,ls_constraint_inf=constraint,
       ls_weighted_residual_norm=float(np.linalg.norm(res)),
       solver_checks_pass=bool(rank==B.shape[1] and stationarity<=K.SOLVER_TOL and constraint<=K.CONSTRAINT_TOL))
