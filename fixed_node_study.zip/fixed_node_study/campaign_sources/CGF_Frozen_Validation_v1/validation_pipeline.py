"""Freeze -> verify -> fresh foundation -> reserved transfer -> review.

No allocation comparison or timing superiority is inferred here. Exact
interior states enter diagnostics only. All candidates are retained; no
candidate, seed, load, or geometry is dropped after looking at its result.
"""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[key]='1'
import hashlib,json,platform,time,traceback,zipfile
from pathlib import Path
import numpy as np
import scipy
from threadpoolctl import threadpool_limits
import validation_base_config as C
import validation_base_engine as E
import validation_settings as K
import validation_solver as S

def signature():
    h=hashlib.sha256()
    for p in sorted(K.HERE.glob('*.py')):
        h.update(p.name.encode());h.update(p.read_bytes())
    h.update((K.HERE/'evidence/recovery_N480_receipts.json').read_bytes())
    h.update(repr((np.__version__,scipy.__version__)).encode())
    return h.hexdigest()

def table(path,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    if rows:E.write_csv(path,rows)

def case_key(case,N,seed,arm,load):
    return f"{case['name']}_N{N}_s{seed}_{arm}_load{load:g}"

def cached(folder,key,fn):
    path=folder/key;receipt=path/'receipt.json';sig=signature()
    if receipt.exists():
        row=json.loads(receipt.read_text())
        if row.get('signature')==sig and row.get('status')=='complete':
            print('RESUME',key,flush=True);return row
    path.mkdir(parents=True,exist_ok=True);print('RUN',key,flush=True);start=time.perf_counter()
    try:
        row=fn(path);row.update(status='complete',elapsed_seconds=time.perf_counter()-start)
    except Exception as exc:
        row=dict(status='failed',key=key,error=f'{type(exc).__name__}: {exc}')
        (path/'error.txt').write_text(traceback.format_exc())
    row['signature']=sig;E.dump(receipt,row)
    print(row['status'],key, 'qualified='+str(row.get('qualified')),flush=True)
    return row

def require(stage,technical_complete=True):
    p=K.OUTPUT_ROOT/stage/'completion.json'
    if not p.exists():raise RuntimeError('Run '+stage+' first.')
    r=json.loads(p.read_text())
    if r.get('signature')!=signature():raise RuntimeError('Protocol/environment changed; rerun '+stage)
    if technical_complete and r['status']!='complete':raise RuntimeError(stage+' has technical failures; inspect its errors.')
    return r

def solve(case,N,seed,arm,load):
    C.STENCIL=25
    m=E.build(case,N,seed);v,b=E.solve(m,load)
    if arm.startswith('ls_'):v,extra=S.ls_solve(m,b,arm,seed,load)
    else:extra=dict(solver_checks_pass=bool(np.linalg.norm(m['A']@v-b)/max(np.linalg.norm(b),1e-30)<=1e-8))
    return m,v,b,extra

def evaluate(m,v,b,arm,load,extra):
    d=E.diagnostics(m,v,b,load)
    if arm.startswith('ls_'):
        for name in ('consistency_response_inf','decomposition_identity_error','discrete_inf_bound',
                     'inverse_inf_norm','nodal_consistency_inf','reconstruction_inf'):
            d.pop(name,None)
    d.pop('qualified',None)
    d['original_equation_relative_residual']=d.pop('algebraic_relative')
    p,w,D0,D1,ref=S.interface_operator(m,K.DENSE_INTERFACE_POINTS)
    dense_flux=S.weighted_norm((D0-D1)@v,w)/max(S.weighted_norm(D0@v,w),1e-12)
    dense_flux_ref=S.weighted_norm((D0-D1)@v,w)/max(S.weighted_norm(ref,w),1e-12)
    truth=E.exact(p,m['case'],0,load)[0];den=max(S.weighted_norm(truth,w),1e-12)
    traces=[]
    for side in (0,1):
        R=E.operator(m,p,sides=np.full(len(p),side));traces.append(S.weighted_norm(R@v-truth,w)/den)
    x=np.linspace(.009,.991,K.DENSE_FIELD_GRID);xx,yy=np.meshgrid(x,x)
    pp=np.column_stack([xx.ravel(),yy.ravel()]);u=E.exact(pp,m['case'],load=load)[0]
    uh=E.operator(m,pp)@v
    dense_bulk=float(np.sqrt(np.mean((u-uh)**2))/max(np.sqrt(np.mean(u**2)),1e-12))
    failures=[name for name,tol in K.PHYSICAL_LIMITS.items() if not np.isfinite(d[name]) or d[name]>tol]
    extra_failures=[]
    for name,value,tol in [('dense_flux',dense_flux,.05),('dense_bulk',dense_bulk,.05),
                            ('dense_trace_left',traces[0],.02),('dense_trace_right',traces[1],.02)]:
        if not np.isfinite(value) or value>tol:extra_failures.append(name)
    if not extra['solver_checks_pass']:extra_failures.append('solver_checks')
    return dict(**d,**extra,dense_flux_jump_relative=float(dense_flux),
       dense_flux_jump_exact_reference_relative=float(dense_flux_ref),
       dense_bulk_relative=dense_bulk,dense_trace_left_relative=float(traces[0]),
       dense_trace_right_relative=float(traces[1]),
       physical_screen_pass=not failures,failed_criteria=failures+extra_failures,
       qualified=not failures and not extra_failures)

def numerical_case(dest,case,N,seed,arm,load):
    start=time.perf_counter();m,v,b,extra=solve(case,N,seed,arm,load)
    solve_seconds=time.perf_counter()-start
    d=evaluate(m,v,b,arm,load,extra)
    np.savez_compressed(dest/'state.npz',nodes=m['nodes'],sides=m['sides'],kinds=m['kinds'],solution=v,rhs=b,
       A_data=m['A'].data,A_indices=m['A'].indices,A_indptr=m['A'].indptr,A_shape=m['A'].shape)
    return dict(case=case['name'],case_parameters=case,budget=N,seed=seed,arm=arm,load=load,**d,
       assembly_solve_seconds=solve_seconds,
       node_layout_signature=hashlib.sha256(m['nodes'].tobytes()).hexdigest(),
       state_matrix_role='reference square collocation operator; LS solution does not assert A v=b',
       timing_note='Includes reference square factorization for LS; not a production cost comparison.')

def verification_checks():
    checks=[];C.STENCIL=25
    def check(name,value,tol):
        value=float(value)
        if not np.isfinite(value) or value>tol:raise AssertionError((name,value,tol))
        checks.append(dict(check=name,value=value,limit=tol,passed=True))
    # Independent polynomial reproduction tests for value, Laplacian and normal derivative.
    rng=np.random.default_rng(1729);nodes=rng.random((80,2));point=np.array([.37,.43])
    P=E.poly(nodes);n=np.array([.6,.8]);x,y=point
    for name,op,truth in [('value','value',E.poly(point[None,:])[0]),
       ('laplacian','lap',np.array([0,0,0,2,0,2])),
       ('normal',n,np.array([0,.6,.8,1.2*x,.8*x+.6*y,1.6*y]))]:
        ids,w=E.weights(nodes,point,op);check('quadratic_'+name,np.max(np.abs(w@P[ids]-truth)),1e-8)
    for case in C.TRAIN+C.HOLDOUT:
        n,t,c,lo,hi=E.geometry(case);p=c+np.linspace(lo,hi,41)[:,None]*t
        for load in K.LOADS:
            u0,g0,_=E.exact(p,case,0,load);u1,g1,_=E.exact(p,case,1,load)
            label=case['name']+'_load'+str(load)
            check(label+'_trace',np.max(np.abs(u0-u1)),1e-10)
            check(label+'_flux',np.max(np.abs(g0@n-case['contrast']*(g1@n))),1e-10)
            # Independent finite differences on each analytic material extension.
            for side in (0,1):
                pp=E.sample_side(12,case,side,317+side);h=1e-4
                u=E.exact(pp,case,side,load)[0];lap=np.zeros(len(pp))
                for axis in (0,1):
                    shift=np.zeros(2);shift[axis]=h
                    lap+=(E.exact(pp+shift,case,side,load)[0]-2*u+E.exact(pp-shift,case,side,load)[0])/h**2
                k=1. if side==0 else case['contrast'];f=E.exact(pp,case,side,load)[2]
                check(label+'_forcing_side'+str(side),np.max(np.abs(k*lap+f))/max(1.,np.max(np.abs(f))),2e-5)
            src,srcabs=E.source_integral(case,48,load);flux=0.
            for a,b,norm,side in E.boundary_segments(case):
                pp,w=E.gauss_segment(a,b,48);k=1. if side==0 else case['contrast']
                flux+=w@(-k*(E.exact(pp,case,side,load)[1]@norm))
            check(label+'_exact_global_balance',abs(flux-src)/max(srcabs,1e-12),1e-9)
    # Independent piecewise quadratic solution has zero consistency error up to
    # floating point error. It tests the full constrained solve and both loads.
    saved_exact=E.exact
    def quadratic(p,case,side=None,load=0.):
        p=np.asarray(p);r,s=E.coordinates(p,case)
        k=np.where(r<=0,1.,case['contrast']) if side is None else (1. if side==0 else case['contrast'])
        n,t,_,_,_=E.geometry(case)
        u=(1+load)*s+(r+r*r)/k
        grad=((1+2*r)/k)[:,None]*n+(1+load)*np.broadcast_to(t,(len(p),2))
        return u,grad,np.full(len(p),-2.)
    try:
        E.exact=quadratic
        for case in C.TRAIN+C.HOLDOUT:
            for load in K.LOADS:
                for arm in K.ARMS:
                    m,v,b,extra=solve(case,80,19,arm,load)
                    truth=quadratic(m['nodes'],case,load=load)[0]
                    check('quadratic_solution_'+case['name']+'_'+arm+'_load'+str(load),np.max(np.abs(v-truth)),1e-8)
                    if not extra['solver_checks_pass']:raise AssertionError('Quadratic solver check failed')
    finally:E.exact=saved_exact
    return checks

def stage09():
    folder=K.OUTPUT_ROOT/'09_verification';folder.mkdir(parents=True,exist_ok=True)
    with threadpool_limits(limits=1):
        checks=verification_checks()
        E.dump(folder/'independent_checks.json',dict(checks=checks,status='passed'))
        refs=json.loads((K.HERE/'evidence/recovery_N480_receipts.json').read_text());rows=[]
        if len(refs)!=12:raise RuntimeError('Expected twelve recovery reference cases.')
        for old in refs:
            case=C.TRAIN[0];key=case_key(case,480,old['seed'],old['arm'],0.)
            def replay(dest,old=old):
                m,v,b,extra=solve(C.TRAIN[0],480,old['seed'],old['arm'],0.)
                r=evaluate(m,v,b,old['arm'],0.,extra)
                metrics=list(K.PHYSICAL_LIMITS)+['dense_flux_jump_relative']
                diff=max(abs(r[k]-old[k]) for k in metrics)
                if diff>1e-7:raise AssertionError('Recovery formulation changed during port: '+str(diff))
                return dict(arm=old['arm'],seed=old['seed'],maximum_reference_difference=diff)
            rows.append(cached(folder,key,replay))
    table(folder/'replay_table.csv',rows)
    result=dict(status='complete' if all(r['status']=='complete' for r in rows) else 'completed_with_failures',
       independent_checks=len(checks),replays=len(rows),signature=signature())
    E.dump(folder/'completion.json',result);print(result,flush=True)

def stage10():
    require('09_verification');folder=K.OUTPUT_ROOT/'10_fresh_foundation';rows=[]
    with threadpool_limits(limits=1):
        for seed in K.SEEDS:
            for N in K.FOUNDATION_BUDGETS:
                for arm in K.ARMS:
                    case=C.TRAIN[0];key=case_key(case,N,seed,arm,0.)
                    rows.append(cached(folder,key,lambda dest,c=case,n=N,s=seed,a=arm:numerical_case(dest,c,n,s,a,0.)))
    complete_stage(folder,rows,36)

def stage11():
    require('09_verification');require('10_fresh_foundation')
    # Scientific failures do not stop predeclared transfer controls. Technical
    # failures must be resolved so incomplete branches cannot masquerade as evidence.
    folder=K.OUTPUT_ROOT/'11_reserved_transfer';rows=[]
    with threadpool_limits(limits=1):
        for case in C.HOLDOUT:
            for seed in K.SEEDS:
                for load in K.LOADS:
                    for arm in K.ARMS:
                        key=case_key(case,K.TRANSFER_BUDGET,seed,arm,load)
                        rows.append(cached(folder,key,lambda dest,c=case,s=seed,a=arm,l=load:numerical_case(dest,c,K.TRANSFER_BUDGET,s,a,l)))
    complete_stage(folder,rows,48)

def complete_stage(folder,rows,expected):
    table(folder/'case_table.csv',rows)
    layout={}
    for r in rows:
        if r['status']=='complete':layout.setdefault((r['case'],r['budget'],r['seed'],r['load']),set()).add(r['node_layout_signature'])
    matched=all(len(v)==1 for v in layout.values())
    done=len(rows)==expected and all(r['status']=='complete' for r in rows) and matched
    result=dict(status='complete' if done else 'completed_with_failures',signature=signature(),
       expected=expected,cases=len(rows),completed=sum(r['status']=='complete' for r in rows),matched_nodes=matched,
       qualified=sum(r.get('qualified',False) for r in rows))
    E.dump(folder/'completion.json',result);print(result,flush=True)

def stage12():
    folder=K.OUTPUT_ROOT/'12_review';folder.mkdir(parents=True,exist_ok=True);sig=signature()
    stages={};rows={}
    for name in ['09_verification','10_fresh_foundation','11_reserved_transfer']:
        p=K.OUTPUT_ROOT/name/'completion.json';stages[name]=json.loads(p.read_text()) if p.exists() else dict(status='missing')
        rows[name]=[json.loads(p.read_text()) for p in sorted((K.OUTPUT_ROOT/name).glob('*/receipt.json'))]
        rows[name]=[r for r in rows[name] if r.get('signature')==sig]
    complete=all(r.get('status')=='complete' and r.get('signature')==sig for r in stages.values())
    results=[];paired=[]
    for arm in K.ARMS:
        f=[r for r in rows['10_fresh_foundation'] if r.get('arm')==arm and r['status']=='complete']
        top=[r for r in f if r['budget']==max(K.FOUNDATION_BUDGETS)]
        t=[r for r in rows['11_reserved_transfer'] if r.get('arm')==arm and r['status']=='complete']
        fpass=len(top)==3 and all(r['qualified'] for r in top)
        tpass=len(t)==12 and all(r['qualified'] for r in t)
        results.append(dict(arm=arm,foundation_completed=len(f),foundation_qualified=sum(r['qualified'] for r in f),
          highest_budget_qualified=sum(r['qualified'] for r in top),highest_budget_expected=3,
          transfer_completed=len(t),transfer_qualified=sum(r['qualified'] for r in t),transfer_expected=12,
          fresh_foundation_pass=fpass,transfer_pass=tpass,validated_on_declared_suite=bool(complete and fpass and tpass)))
    for branch in ['10_fresh_foundation','11_reserved_transfer']:
        good=[r for r in rows[branch] if r['status']=='complete']
        for r in good:
            b=next((b for b in good if b['arm']=='square25' and all(b[k]==r[k] for k in ['case','budget','seed','load'])),None)
            if b:
                paired.append(dict(branch=branch,case=r['case'],budget=r['budget'],seed=r['seed'],load=r['load'],arm=r['arm'],
                  bulk_ratio=r['bulk_relative']/max(b['bulk_relative'],1e-300),
                  flux_ratio=r['flux_jump_relative']/max(b['flux_jump_relative'],1e-300),qualified=r['qualified']))
    table(folder/'candidate_summary.csv',results);table(folder/'paired_changes.csv',paired)
    candidates=[r['arm'] for r in results if r['arm']!='square25' and r['validated_on_declared_suite']]
    verdict='INCOMPLETE' if not complete else ('VALIDATED_ON_DECLARED_SUITE' if candidates else 'NO_CANDIDATE_PASSES_DECLARED_SUITE')
    E.dump(folder/'adjudication.json',dict(status=verdict,stages=stages,validated_candidates=candidates,
       original_scripts_02_03_ready=False,
       next='Review all failures and comparisons. A successful new operator must be integrated consistently into all allocation, pilot and adjoint arms before cost claims.'))
    lines=['# Frozen validation review','',f'Status: **{verdict}**','',
       '| Arm | Fresh cases passed / 9 | Highest budget / 3 | Reserved transfer / 12 | Declared suite passed |',
       '|---|---:|---:|---:|---|']
    for r in results:lines.append(f"| {r['arm']} | {r['foundation_qualified']} | {r['highest_budget_qualified']} | {r['transfer_qualified']} | {r['validated_on_declared_suite']} |")
    lines+=['','The suite requires all stages to finish, every highest-budget fresh seed to qualify, and all twelve reserved-transfer cases to qualify for a candidate.',
      'The dense field and two-sided trace checks supplement the original physical thresholds. LS stationarity and exact constraints replace the square solver residual check only for LS arms.',
      'This is finite evidence for these two-dimensional, straight-interface problems. It proves neither uniform stability nor universal superiority.',
      'Original scripts 02/03 still use the original operator. They cannot assess the validated formulation without a consistent update.',
      'Return the complete results ZIP for the next decision.']
    (folder/'REVIEW.md').write_text('\n'.join(lines)+'\n')
    archive=K.HERE/'CGF_Frozen_Validation_v1_results.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(K.OUTPUT_ROOT.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(K.HERE))
    print(verdict+'\nReturn: '+str(archive),flush=True)

def run(stage):
    K.OUTPUT_ROOT.mkdir(parents=True,exist_ok=True)
    E.dump(K.OUTPUT_ROOT/'environment.json',dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,signature=signature()))
    print('Frozen validation; single thread. Outputs:',K.OUTPUT_ROOT,flush=True)
    return {9:stage09,10:stage10,11:stage11,12:stage12}[stage]()
