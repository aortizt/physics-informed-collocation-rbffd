# Review of the uploaded recovery run

All required branches completed: 9/9 archive diagnoses and 54/54 controls. The decisions agree with the independent local run. Across bulk, trace, flux, dense-flux and balance diagnostics, the largest absolute difference was about 4.21e-10. This supports numerical reproducibility across the two NumPy/SciPy environments.

| Formulation | All-budget screen / 9 | N=480 screen / 3 | N=480 flux-jump range |
|---|---:|---:|---:|
| square25 | 0/9 | 0/3 | 23.08–30.84% |
| square37 | 2/9 | 2/3 | 2.62–6.79% |
| ls_nodal | 0/9 | 0/3 | 23.08–30.84% |
| ls_flux | 7/9 | 3/3 | 1.26–2.21% |
| ls_pde | 6/9 | 3/3 | 1.46–2.52% |
| ls_both | 6/9 | 3/3 | 1.26–2.35% |

## What the controls establish

The nodal least-squares control reproduces the original failures. Merely changing the solve method did not repair them. Extra flux equations, extra PDE equations, and their combination all improve the highest-budget cases on identical nodes. Increasing the stencil alone helps but fails for one of the three seeds.

This is evidence for changing equation enforcement as a repair route. It is not an allocation benefit: node positions were held fixed. Neither higher interface density nor a Green-function allocation advantage was tested here. The amplified consistency-error diagnosis remains consistent with these results.

The three successful candidates differ: flux-only passed 7/9 cases overall; PDE-only and combined passed 6/9. All passed 3/3 at N=480. These counts and the three-seed sample do not justify declaring a universal winner. Preserve all three candidates for the frozen validation.

## Remaining question

Does the improvement survive fresh node layouts, rotated interfaces, different coefficient contrasts, and a controlled changed load? Scripts 09–12 address exactly that question, using the originally reserved two transfer geometries. No tolerance or candidate is adjusted after their results.

## Pipeline consequence

Original scripts 02/03 still solve and differentiate the old square operator. Even if a new candidate validates, they must be updated consistently for its constrained least-squares solution map. Running them unchanged would answer a question about the failed original formulation. The next numerical step is therefore the frozen validation package.
