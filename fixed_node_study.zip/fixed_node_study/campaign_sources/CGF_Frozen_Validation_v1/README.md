# CGF Frozen Validation v1

## Run these four scripts in Spyder

Extract this entire folder under your project, for example:
`/home/dakini/Downloads/012-MADV_AOT_collocation/CGF_Frozen_Validation_v1`

Press F5 in this order, one script at a time:

1. `09_Verification_Spyder.py`
2. `10_Fresh_Foundation_Spyder.py`
3. `11_Reserved_Transfer_Spyder.py`
4. `12_Review_and_Package_Spyder.py`

Run all four before returning results. A completed scientific failure is retained
and does not stop the next experiment. If a technical error stops a script,
run 12 to package the partial outputs and return the ZIP for diagnosis.

Return **CGF_Frozen_Validation_v1_results.zip**, created inside this extracted
folder. No command-line arguments, manual input paths, previous output folders,
network access or new packages are required. Dependencies remain NumPy, SciPy
and threadpoolctl. Starting a fresh Spyder kernel is recommended when switching
packages; this package also uses distinct module names.

Outputs live in `CGF_Frozen_Validation_v1_outputs`, with one subfolder per script
and per case. Completed cases resume under the same source, reference data and
NumPy/SciPy versions. A failed case is retried. The large evidence-recovery
archive is not needed. No old source or results are edited.

## Why this stage exists

Your recovery run reproduced the local result: the original square solve and
the nodal least-squares control fail; adding equation samples on unchanged nodes
gives three promising candidates. Those results used the original training
seeds. They cannot establish behavior on new node layouts or material interfaces.

The three candidates and square25 baseline are now frozen. Each uses stencil 25,
the same node allocation and the same physical error thresholds as before.
The LS weights, exact constraints and oversampling factors are unchanged.

| Stage | Cases and purpose |
|---|---|
| 09 | Independent polynomial/operator, forcing, jump and balance checks; complete piecewise-quadratic solves; reproduce all 12 retained N=480 recovery reference cases. |
| 10 | 36 runs: vertical interface, fresh seeds 53/71/89, budgets 120/240/480, four formulations. |
| 11 | 48 runs: the two reserved oblique geometries, the same three fresh seeds, N=480, loads 0 and 0.25, four formulations. |
| 12 | Joint review, paired tables, complete or partial results ZIP. |

The two transfer cases were already reserved in the original package:

| Case | Angle | Center | Material contrast | Source frequency |
|---|---:|---|---:|---:|
| oblique_holdout | 25 degrees | (0.52, 0.47) | 50 | 1.4 |
| oblique_low_contrast | -20 degrees | (0.46, 0.53) | 5 | 0.8 |

Load 0.25 changes the coefficient of the manufactured tangential term from 1
to 1.25, and therefore changes its forcing and exterior data. It is a controlled
second right-hand side, not a completely independent forcing family. No
factorization-reuse or amortized cost claim is made in this stage.

## Formulations and qualification

- square25: original square collocation baseline.
- ls_flux: exact exterior and nodal trace constraints, with extra interface flux equations.
- ls_pde: the same constraints, with extra interior PDE equations.
- ls_both: both additions.

An LS candidate qualifies on the declared suite only if verification and every
branch complete, all three highest-budget fresh foundation cases qualify, and
all twelve transfer cases qualify. Lower-budget failures remain visible.
All candidates are tested, including any that fail a training condition.

The original five physical thresholds remain: trace 2%, bulk 5%, balance 5%,
flux jump 5%, and quadrature-change scale 0.5%. The existing 257-point interface
flux screen also remains. New independent checks use a 61-by-61 field grid and
both interface traces on the 257-point grid, with the same 5%/2% tolerances.
This strengthens sampling; it does not loosen an original threshold.

Square solves require relative algebraic residual <=1e-8. LS solves instead
require full column rank, normalized stationarity <=1e-8, and exact-constraint
error <=1e-10. The original square residual is still reported for LS solutions,
but least squares generally cannot make every overdetermined equation exact.

Read `FROZEN_PROTOCOL.md` for mathematical details and `RECOVERY_REVIEW.md` for
the evidence motivating this stage. `LOCAL_VALIDATION.md` reports the local
execution of this frozen protocol. Those results never substitute for your run.

## What happens after this stage

Return the result ZIP for review. The original scripts 02/03 still use the
original square solver. They need a consistent update if an LS candidate is
adopted: the pilot, allocation comparisons, sensitivity/adjoint calculation
and cost accounting must all use the declared formulation. A transpose solve
for the old square operator is not the adjoint of the new constrained
least-squares solution map. No automatic old-pipeline gate override is made.

