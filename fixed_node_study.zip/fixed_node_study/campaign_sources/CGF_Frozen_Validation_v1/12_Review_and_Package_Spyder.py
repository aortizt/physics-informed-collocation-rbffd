"""Run with F5 in Spyder; no command-line arguments."""
from pathlib import Path
import importlib,sys
HERE=Path(__file__).resolve().parent
if str(HERE) in sys.path:sys.path.remove(str(HERE))
sys.path.insert(0,str(HERE))
import validation_settings,validation_base_config,validation_base_engine,validation_solver,validation_pipeline
for module in (validation_settings,validation_base_config,validation_base_engine,validation_solver,validation_pipeline):
    importlib.reload(module)
if __name__=='__main__':validation_pipeline.run(12)
