# Frozen protocol and interpretation

This protocol was written before running the fresh seeds and reserved transfer
cases. Candidate membership, weights, stencil, budgets, seeds, loads, geometry
and tolerances are not adjusted after inspecting those results.

## Problem and information

The square domain is split by a straight material interface r=n dot (x-c)=0,
with tangential coordinate s=t dot (x-c). Solve -div(K grad u)=f with prescribed
exterior Dirichlet data, continuous trace and continuous conormal derivative.
The piecewise coefficient is 1 or the declared contrast. The manufactured state
is the same as in the bounded extension:

    u_i = (1+load) sin(w s) + r q(s)/K_i + h(r) sin(w s)/K_i,
    q(s)=1+0.2 cos(2 w s), h(r)=r^2 cos(pi r), w=pi*frequency.

Analytically differentiated forcing and prescribed boundary values are input.
Exact interior state and flux enter diagnostics only. Node locations do not
depend on the manufactured interior error or validation outcomes.

## Frozen constrained least-squares formulation

Represent nodal coefficients as v=g+T y, where g inserts exterior values and T
shares each paired interface trace unknown. The original row-normalized PDE
and conormal equations are retained. Add the same independent samples as in
the recovery experiment: two new PDE evaluations per original interior node
for each material; four times the original interface-node count for extra
conormal equations, evaluated at midpoints of equal interface intervals.

The PDE sample seed is the case seed plus 50000 plus 101 times the material
side. Every added equation is divided by its full coefficient-row l1 norm.
The left PDE, right PDE and flux groups each receive an additional factor
1/sqrt(group equation count). Thus each contributes a mean squared residual.

For the normalized equations H v approximately f, solve

    minimize_y || B y-d ||_2, B=H T, d=f-H g.

The dense SVD solver uses its default numerical rank criterion. Full column
rank, normalized stationarity and exact constraints are recorded. No normal
equations, post-hoc regularization, or fitting to exact interior error is used.

The original recovery implementation is preserved mathematically; only explicit
load propagation is added to boundary and forcing assembly. Stage 09 checks
all twelve N=480 recovery references and independently solves a piecewise
quadratic with two loads. These checks would expose a missing load argument.

For LS states the saved A and rhs refer to the original square operator. The
saved LS solution does not assert A v=b. The complete LS operator is recreated
from the bundled source, case, seed, nodes, load and formulation. Square-system
error decomposition and inverse-bound fields that would be invalid for an LS
solution are excluded from its diagnostic receipt.

## Qualification and comparisons

All original physical metrics retain their original normalization and thresholds.
Independent dense checks use midpoint interface samples and a 61-by-61 field
grid distinct from the original 31-by-31 grid. Both one-sided trace errors are
checked. Finite sampling does not prove a continuum error supremum bound.
The two different interface quadratures also do not prove quadrature convergence.

The suite passes for a candidate only if all required branches finish and all
three highest-budget fresh foundation cases plus all twelve reserved transfer
cases qualify. The result is finite validation for a restricted problem class.
There is no pooled conclusion while a required branch is missing. Repeated
seeds across budgets and the two related loads are not independent replicates.

The LS controls use identical nodes to the square baseline. A gain reflects
changed equation enforcement on those nodes, not improved allocation. Dense
SVD and an extra reference factorization make the recorded times unsuitable
for a fair production efficiency claim. Cost comparisons remain a separate
experiment after a formulation is selected and implemented consistently.

## Relation to interface methods and future sensitivities

No Trefftz-Herrera completeness or elimination of volume forcing is supplied
by these changes. Local forcing remains explicit. Appropriate weight families,
completeness and local particular solutions are separate mathematical matters.
Changing the information enforced by a discretization is distinct from merely
concentrating its nodes near an interface.

For fixed full-column-rank B, the derivative of y with respect to d is B's
pseudoinverse. Its objective sensitivity must account for the constraint map T
and all equation weights. The old square A-transpose solve is therefore not
automatically the correct sensitivity for this formulation. This motivates
updating the later pilot/adjoint pipeline before resuming efficacy comparisons.

Related primary literature: I. Tominec, E. Larsson and A. Heryudono,
*A Least Squares Radial Basis Function Finite Difference Method with Improved
Stability Properties*, SIAM Journal on Scientific Computing (2021),
DOI 10.1137/20M1320079, https://arxiv.org/abs/2003.03132.
This experiment has its own constrained formulation and weights; that paper's
stability analysis is not claimed to establish stability of this code.
