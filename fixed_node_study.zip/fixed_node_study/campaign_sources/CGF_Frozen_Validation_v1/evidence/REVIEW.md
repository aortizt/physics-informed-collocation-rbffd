# Foundation recovery review

Status: **CANDIDATES_REQUIRE_NEW_VALIDATION**

All six arms are required for complete synthesis. Earlier results are preserved.

| Arm | Completed / 9 | Physical screen / 9 | Diagnostic screen / 9 | Highest budget / 3 |
|---|---:|---:|---:|---:|
| square25 | 9 | 0 | 0 | 0 |
| square37 | 9 | 3 | 2 | 2 |
| ls_nodal | 9 | 0 | 0 | 0 |
| ls_flux | 9 | 7 | 7 | 3 |
| ls_pde | 9 | 6 | 6 | 3 |
| ls_both | 9 | 6 | 6 | 3 |

The diagnostic screen combines the original five physical criteria, a solver check appropriate to the method, and an independent 257-point interface flux check.
Original algebraic residuals and literal v1 threshold attainment are recorded separately for every control.
The LS nodal arm controls for the change of solver and constraints; compare LS flux/PDE/both with it as well as with square25.
Neither training qualification nor a small residual establishes uniform stability or an allocation benefit.

Next: return this entire results ZIP for review. Keep original scripts 02 and 03 on hold.
