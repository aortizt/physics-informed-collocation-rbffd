"""Independent identities and numerical controls; run before production branches.
This is verification of implementation, not proof of uniform stability.
"""
from pathlib import Path
import sys,importlib
HERE=Path(__file__).resolve().parent
if str(HERE) not in sys.path:sys.path.insert(0,str(HERE))
import config,engine
importlib.reload(config);importlib.reload(engine)
import numpy as np
from threadpoolctl import threadpool_limits

def main():
    E=engine;C=config;checks=[]
    with threadpool_limits(limits=1):
        rng=np.random.default_rng(19);nodes=rng.random((50,2));point=np.array([.43,.61])
        P=E.poly(nodes)
        expected={'value':E.poly(point[None,:])[0], 'lap':np.array([0,0,0,2,0,2])}
        for op,truth in expected.items():
            ids,w=E.weights(nodes,point,op);err=float(np.max(np.abs(w@P[ids]-truth)))
            assert err<1e-8,(op,err);checks.append(dict(check=f'quadratic_reproduction_{op}',error=err))
        direction=np.array([.6,.8]);ids,w=E.weights(nodes,point,direction)
        dx,dy=direction;x,y=point;truth=[0,dx,dy,2*x*dx,y*dx+x*dy,2*y*dy]
        err=float(np.max(np.abs(w@P[ids]-truth)));assert err<1e-8
        checks.append(dict(check='directional_reproduction',error=err))
        for case in C.TRAIN+C.HOLDOUT:
            n,t,c,lo,hi=E.geometry(case);s=np.linspace(lo,hi,25);p=c+s[:,None]*t
            u0,g0,f0=E.exact(p,case,0);u1,g1,f1=E.exact(p,case,1)
            err=float(max(np.max(np.abs(u0-u1)),np.max(np.abs(g0@n-case['contrast']*(g1@n)))))
            assert err<1e-10;checks.append(dict(check=case['name']+'_exact_jump_conditions',error=err))
            # Independent centered differentiation checks analytic forcing away from Sigma.
            p=E.sample_side(8,case,0,31);h=1e-4;u=E.exact(p,case,0)[0];lap=0.
            for axis in (0,1):
                d=np.zeros(2);d[axis]=h
                lap+=(E.exact(p+d,case,0)[0]-2*u+E.exact(p-d,case,0)[0])/h**2
            f=E.exact(p,case,0)[2];err=float(np.max(np.abs(lap+f)))
            assert err<2e-5;checks.append(dict(check=case['name']+'_analytic_forcing',error=err))
            order=48;src,abs_src=E.source_integral(case,order,0);flux=0.
            for a,b,norm,side in E.boundary_segments(case):
                pp,w=E.gauss_segment(a,b,order);k=1. if side==0 else case['contrast']
                flux+=w@(-k*(E.exact(pp,case,side)[1]@norm))
            err=float(abs(flux-src)/max(abs_src,1e-12));assert err<1e-9
            checks.append(dict(check=case['name']+'_exact_global_balance',error=err))
        m=E.build(C.TRAIN[0],80,11);v,b=E.solve(m)
        z=m['lu'].solve(m['objective'],trans='T');d=rng.normal(size=len(v))
        err=float(abs(z@d-m['objective']@m['lu'].solve(d)));assert err<1e-7
        checks.append(dict(check='transpose_sensitivity_identity',error=err))
        diag=E.diagnostics(m,v,b)
        assert diag['decomposition_identity_error']<1e-8
        assert diag['discrete_inf_bound'] is None or diag['field_error_inf']<=diag['discrete_inf_bound']+1e-8
        checks.append(dict(check='finite_system_error_identity',error=diag['decomposition_identity_error']))
    E.dump(C.OUTPUT_ROOT/'04_verification'/'checks.json',dict(status='passed',checks=checks,
      note='Production foundation and cost-to-accuracy verdicts remain open.'))
    print('All independent checks passed.',flush=True)
if __name__=='__main__':main()
