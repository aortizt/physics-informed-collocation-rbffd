# Mathematical protocol and interpretation

## 1. PDE and available physical information

Omega=(0,1)^2 is divided by a straight interface r=n dot (x-c)=0.
s=t dot (x-c), with n,t orthonormal. K=1 or the specified contrast.
Solve -div(K grad u)=f with prescribed exterior Dirichlet data,
[u]=0 and [K partial_n u]=0 on the interface. Smoothness is piecewise,
not global. The implementation has duplicate interface nodes and simultaneous
trace and conormal equations; every local stencil stays in its material.

The manufactured nonpolynomial state is

u_i = (1+ell) sin(w s) + r q(s)/K_i + h(r) sin(w s)/K_i,
q(s)=1+0.2 cos(2 w s), h(r)=r^2 cos(pi r), w=pi*frequency.

At r=0, the trace is common and K_i partial_r u_i=q(s).
Source f_i=-K_i Delta u_i is analytically differentiated in the code.
Rotation, interface position, contrast and frequency change on holdout.
No curved interface, transient problem, SPE10 superiority or DDM scalability
claim follows from this restricted class.

The method uses cubic polyharmonic splines and quadratic augmentation with
25-node same-material stencils. Protected skeleton points account for 55% of
each material's interior budget; all arms use the same minimum-separation safeguard,
and enrichment uses reproducible weighted keys
with minimum separation. Boundary/interface nodes grow with sqrt(N) and are
identical for methods at the same N. Costs and total unknowns are reported.
The gap diagnostic is a finite-grid estimate, not an exact fill distance.

## 2. Historical GHG versus new information

Distance proxy: known material geometry; no operator Green function.
GHG proxy: protected coverage plus equally normalized distance and pilot-gradient
scores. This is a declared new proxy realization. It does not reproduce the
old GHG component coefficients or old reconstruction engine.
Residual: prescribed source minus off-node discrete pilot PDE action.
Adjoint: A_tilde^T z = j, where j is a reconstructed interface-mean functional.
The raw-equation sensitivity is row_scale*z. A nearest-pilot-node transfer
multiplies its magnitude by off-node residual. This is an allocation heuristic,
not a derivative with respect to changing the collocation geometry.
Full pilot uses 3*80 interior points; coarse pilot uses 80. These names describe
relative discrete resolution; neither is an exact continuum Green function.
The reusable arm freezes the load=0 score for both declared loads. It tests
sensitivity transfer, and may fail when the source changes.

GHG assumes a useful relationship among a physically identified region,
discretization difficulty, and the chosen error objective. A known interface,
a large gradient or a successful algebraic solve does not establish that
relationship. Influence, consistency, coverage, reconstruction and stability
must all be checked. Gradient blending is an ablation, not an obligation.

## 3. Error identity and finite-system estimate

Let A_tilde c_h=b_tilde, c_v=u evaluated on the nodes, and R the independent
field reconstruction. Define tau=A_tilde c_v-b_tilde. Then

u-R c_h = (u-R c_v) + R A_tilde^{-1} tau.

The first term measures reconstruction/approximation of exact nodal information;
the second measures consistency defect propagated through the discrete solver.
Their separate norms do not imply that their sum attains the sum of norms:
cancellation matters. Identity discrepancy is independently recorded.

For systems with at most 350 unknowns, the code computes the dense discrete
inverse and reports the finite-grid infinity-norm bound

||u-R c_h||_inf <= ||u-R c_v||_inf
                  + ||R||_inf ||A_tilde^{-1}||_inf ||tau||_inf.

Above 350 unknowns that bound and inverse norm are marked unavailable; the exact
error decomposition remains measured. This is not a uniform-N stability or
continuum convergence theorem. Ill-conditioning can make it uninformative.
The cost of exact diagnostic inverses is offline validation, not online policy
cost, and is reported separately. A publishable theorem requires independent
approximation/consistency estimates and uniform stability assumptions or proof.

## 4. Conservation versus quadrature versus normalization

With q=-K grad u, div q=f. Integrate source over material polygons using
triangular Duffy quadrature. Split exterior boundary quadrature at material
crossings. Evaluate reconstructed one-sided normal derivatives on each segment.
Gauss orders 16,32,64 produce a source/flux history. The exact manufactured
flux/source balance is a separate check of forcing and quadrature.

Report |integral_boundary q_h dot n - integral_Omega f| and its normalization by
integral_Omega |f| + integral_boundary |q_h dot n|. Also retain the source-only
relative diagnostic to expose nearly cancelling-source instability. The latter
never replaces absolute balance or the stable physical scale.

A changing flux integral under quadrature refinement suggests unresolved
quadrature of the reconstructed field. A stable but nonzero defect suggests a
solver/reconstruction conservation issue; neither observation alone proves the
cause. Stencil switching can make reconstructed derivatives only piecewise
smooth, so increasing Gauss order need not give monotone convergence. Only a
single comparison of the last two orders is used as a declared screening gate;
if ambiguous, extend/refine quadrature in a separate documented investigation.
This collocation method is not constructed to conserve cell fluxes exactly.
A conservation failure can motivate conservative reformulation in a new stage.

## 5. Gates, costs and interpretation

Predeclared qualification: trace-relative L2 <=0.02; bulk-relative RMS <=0.05;
normalized global balance <=0.05; relative flux jump <=0.05;
last quadrature-change scale <=0.005; algebraic relative residual <=1e-8.
Trace accuracy and signed interface-mean objective error are different metrics:
a small mean error may result from cancellation. Report both.

Foundation passes only if every highest-budget training Halton case qualifies.
A failed foundation blocks later branches by default. Explicit descriptive
continuation can diagnose failure but cannot authorize efficacy claims.
Branch 2 completion and a passed foundation are required before pooled branch 3
claims. No claim is allowed from smoke mode. All failed cases remain visible.
Single-thread timings include pilot setup/solve/adjoint where used, scoring,
node construction, target matrix/factorization and solve. Offline exact
validation and IO are excluded uniformly and their time is separately recorded.
The reuse experiment amortizes setup over the declared two loads at each N.
Halton also gets a factorization-reuse arm. Both are distinct from fresh solves.
State extraction, manuscript archaeology and global scientific QA are not
charged as online solver work.

Production initially tries N=120,240,480 and affordable Halton N=720,960.
A finite budget search is not an estimate of the best possible Halton method.
If informed costs exceed every attempted Halton cost, the affordable frontier
is unresolved and more Halton budgets must be run. No asymptotic extrapolation
or automatic superiority label is permitted. Timings from other machines or
historical solvers must not be combined. Repeated seeds across budgets are not
independent observations; case-level matched comparisons precede any inference.

## 6. Why this is not Trefftz-Herrera

Chapter 3, equations (3.4)-(3.9), requires TH completeness of the chosen weight
family. Volume elimination uses weights in the appropriate nullspaces; local
particular solutions handle nonzero forcing in (3.12)-(3.18). Truncation adds
approximation error. Chapter 5 develops the adjoint and interface functionals.
None of these conditions is supplied by putting more nodes near Sigma.
A future experiment must explicitly construct physically chosen functionals,
measure truncation error and compare against pointwise enforcement with a
common problem and cost protocol. It must not inherit positive findings from
this allocation experiment simply because both mention interfaces.
