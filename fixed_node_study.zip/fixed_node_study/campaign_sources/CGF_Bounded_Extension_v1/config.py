from pathlib import Path
# All scripts run with F5 in Spyder; no command-line arguments.
PROJECT_ROOT = Path('/home/dakini/Downloads/012-MADV_AOT_collocation')
OUTPUT_ROOT = PROJECT_ROOT / 'CGF_Bounded_Extension_v1_outputs'
PROFILE = 'production'  # 'smoke' verifies plumbing; it is not publication evidence.
BUDGETS = [120, 240, 480]
SEEDS = [11, 23, 37]
STENCIL = 25
PROTECTED_FRACTION = 0.55
PILOT_BUDGET = 80
INTERFACE_REL_TOL = 0.02
BULK_REL_TOL = 0.05
BALANCE_TOL = 0.05
QUADRATURE_TOL = 0.005
# Frozen before holdout; never choose parameters using exact interior values.
DISTANCE_WIDTH = 0.08
FULL_PILOT_MULTIPLIER = 3
MIN_SPACING_FACTOR = 0.12
QUADRATURE_ORDERS = [16, 32, 64]
EVALUATION_GRID = 31
# y = center is not required; straight material interfaces rotate in the square.
TRAIN = [dict(name='vertical_train', angle=0., cx=.50, cy=.50, contrast=20., freq=1.)]
HOLDOUT = [dict(name='oblique_holdout', angle=25., cx=.52, cy=.47, contrast=50., freq=1.4),
           dict(name='oblique_low_contrast', angle=-20., cx=.46, cy=.53, contrast=5., freq=.8)]
# A scan never executes recovered Python, extracts archives, or edits old results.
SCAN_MAX_MEMBER_BYTES = 16 * 1024 * 1024
SCAN_MAX_ARCHIVE_BYTES = 128 * 1024 * 1024
SCAN_MAX_TABLE_ROWS = 100000
MANUSCRIPT_PATH = None  # optionally set to your submitted .tex, .txt, or .pdf

AFFORDABLE_HALTON_MULTIPLIERS = [1.5, 2.]  # Extend further if informed cost remains higher.

FLUX_JUMP_TOL = 0.05

ALLOW_DESCRIPTIVE_CONTINUATION = False  # A failed foundation requires review, not a forced success.
