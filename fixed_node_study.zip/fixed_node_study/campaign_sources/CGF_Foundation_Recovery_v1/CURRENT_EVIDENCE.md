# Current evidence and next experiment

The original production run completed 9/9 cases; 0/9 met every original qualification criterion. The foundation requires qualification of all three highest-budget cases. The original verification checks passed separately.

## Original highest-budget results (N=480)

| Seed | Trace error (%) | Flux jump (%) | Exact-nodal flux jump (%) | Failed original criteria |
|---|---:|---:|---:|---|
| 11 | 1.274 | 23.080 | 3.424 | flux_jump_relative |
| 23 | 3.526 | 30.841 | 2.311 | interface_relative, flux_jump_relative |
| 37 | 5.228 | 28.029 | 3.471 | interface_relative, flux_jump_relative |

The flux jump at enforced interface nodes is near floating point precision. The between-node flux is the persistent failing criterion. At N=480, reconstructing flux from exact nodal values gives only 2.3–3.5% jump, whereas the actual solutions give 23–31%. The denominators differ in those original metrics; the new diagnostic explicitly places all decomposition terms on a common exact-flux scale.

The archived field error identity also points to propagated consistency error: field reconstruction of exact nodal values is approximately 0.00016–0.00027 in infinity norm at N=480, compared with propagated consistency responses of approximately 0.034–0.095. This does not identify roundoff as the cause. The finite operator amplifies its consistency defects.

At lower budgets, some node layouts are much worse. The seed-37 N=120 field error is about 6.92; its exact-nodal reconstruction error is only about 0.0015. The same source and problem can therefore generate very different accuracy across layouts.

## Local control outcomes

| Arm | Completed | Original physical criteria passed | Additional diagnostic screen passed | Highest-budget screen |
|---|---:|---:|---:|---:|
| square25 | 9/9 | 0/9 | 0/9 | 0/3 |
| square37 | 9/9 | 3/9 | 2/9 | 2/3 |
| ls_nodal | 9/9 | 0/9 | 0/9 | 0/3 |
| ls_flux | 9/9 | 7/9 | 7/9 | 3/3 |
| ls_pde | 9/9 | 6/9 | 6/9 | 3/3 |
| ls_both | 9/9 | 6/9 | 6/9 | 3/3 |

All three oversampling arms qualify at N=480 in this local training study. Increasing the stencil to 37 qualifies two of three. The nodal least-squares control reproduces the original physical diagnostics to within 5e-12 here; merely changing the linear algebra did not improve them. Adding independent equations, on unchanged nodes, produced the observed improvement.

These results support testing equation oversampling as a repair candidate. They do not establish general stability, a Green-function allocation advantage, an interface-only reduction, or a production cost benefit. They do not automatically qualify the original solver.

## Next running sequence

Run 06, then 07, then 08 in Spyder and return the generated results ZIP. The package contains all necessary original input states. This run checks reproducibility in your NumPy 2.2.2 / SciPy 1.15.1 environment. After review, freeze a selected formulation and validate it on fresh seeds and geometries before resuming allocation and cost experiments. The existing holdout has not been used to choose these changes.
