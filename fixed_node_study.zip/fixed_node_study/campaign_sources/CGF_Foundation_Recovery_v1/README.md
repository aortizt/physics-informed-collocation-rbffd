# CGF Foundation Recovery v1

## What to run now

Extract this whole folder beside the previous package, for example into:
`/home/dakini/Downloads/012-MADV_AOT_collocation/CGF_Foundation_Recovery_v1`

Open each script in Spyder and press F5, serially:

1. `06_Archive_Diagnosis_Spyder.py`
2. `07_Matched_Controls_Spyder.py`
3. `08_Review_and_Package_Spyder.py`

Then return **CGF_Foundation_Recovery_v1_results.zip**, created inside this
package's folder. No command-line arguments or path edits are needed. Inputs
are the bundled nine original states and receipts. You do not need to copy the
large evidence-recovery archive. The original package is preserved.

Do not run original scripts 02 and 03 yet. Script 02 has a descriptive
continuation option, but it compares allocation policies rather than isolating
the failed foundation. Enabling that option in v1 requires changing config and
rerunning 01. This package instead runs a dedicated investigation.

Dependencies: NumPy, SciPy, threadpoolctl (already required by v1). No network
access or automatic installation. A fresh Spyder kernel is recommended when
switching packages. Module names are distinct from v1's config and engine.

## What the stages answer

| Script | Question | Work |
|---|---|---|
| 06 | Which original criteria failed, and where is error amplified? | Reproduce saved solves and diagnostics; decompose errors by PDE/trace/flux equations; examine small singular values and interface flux samples. |
| 07 | Does changing the stencil or equation enforcement reduce the failure on identical nodes? | Six declared arms on all nine original cases: 54 runs. |
| 08 | Are all experiments complete, and does any arm justify fresh validation? | Paired changes, qualification counts, written review and a results ZIP. |

Common output folder: `CGF_Foundation_Recovery_v1_outputs`. Each stage and
each case has its own subfolder. Stage 07 requires successful replay of all
nine archived cases. A scientific failure in an individual control is a result
and does not stop the other controls. Technical failures are retained and
prevent complete adjudication. Script 08 can package a partial run if needed.

Completed cases resume when source, bundled evidence and NumPy/SciPy versions
match. Stop and restart a script to resume; never run two scripts concurrently.
Changed source invalidates existing receipts. CSV summaries are rebuilt after
a stage completes; per-case receipts are saved immediately. The local validation
snapshot is separate and is never used as a substitute for your run.

## Six controls (fixed before the local run)

| Arm | Stencil | Extra equations | Purpose |
|---|---:|---|---|
| square25 | 25 | None | Rebuild the original square collocation baseline. |
| square37 | 37 | None | Isolate stencil width on the same nodes. |
| ls_nodal | 25 | None | Control for constrained least-squares solution of nodal equations. |
| ls_flux | 25 | Four times the original interface-node count, at midpoints | Test enforcement of flux continuity between original interface nodes. |
| ls_pde | 25 | Two extra PDE points per original interior node, sampled independently | Test interior equation oversampling. |
| ls_both | 25 | Both additions | Test their combined effect. |

The LS arms impose exterior boundary values and paired interface traces exactly
by eliminating constrained variables. Three residual groups (left PDE, right
PDE, flux) have equal mean-square weight after row normalization. SVD solves
the reduced least-squares system; no normal equations or tunable regularization
are used. Exact interior values enter diagnostic calculations only. The
analytic source and prescribed boundary values are legitimate PDE input.

This is a declared experimental constrained formulation. It is not a replay
of a published LS-RBF-FD implementation and inherits no stability theorem.

## Reading the outcome

The five original physical thresholds remain unchanged. The original equation
residual and literal attainment of all six v1 thresholds are also recorded.
For a least-squares solve, a nonzero original equation residual is expected;
its solver check instead requires full column rank, normalized stationarity
<=1e-8, and exact-constraint error <=1e-10. This distinct diagnostic screen
also requires a 257-point independent interface flux check <=5%.

A candidate must complete every original case and satisfy the screen for all
three N=480 seeds. Candidates are **training evidence**, not permission to
resume efficacy or cost claims. If promising, freeze the operator and run
independent verification and a fresh foundation. This package cannot turn
the old foundation gate into a pass or automatically enable scripts 02/03.

Timings are exploratory: every arm includes a reference square factorization.
They are not a fair production cost comparison. No convergence theorem, DDM
performance, SPE10 result, or superiority of GHG follows from these controls.

Read `MATHEMATICAL_DIAGNOSIS.md` for the error identities and limitations,
`CURRENT_EVIDENCE.md` for the original findings, and `LOCAL_VALIDATION.md` for
the completed checks of this package.

