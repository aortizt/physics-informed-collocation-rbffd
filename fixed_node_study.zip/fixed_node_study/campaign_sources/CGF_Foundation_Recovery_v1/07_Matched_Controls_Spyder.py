"""Run with F5 in Spyder. No command-line arguments."""
from pathlib import Path
import sys, importlib
HERE = Path(__file__).resolve().parent
if str(HERE) in sys.path: sys.path.remove(str(HERE))
sys.path.insert(0, str(HERE))
# Unique module names avoid collision with original package config/engine.
import recovery_config, cgf_v1_config, cgf_v1_engine, recovery
for module in (recovery_config, cgf_v1_config, cgf_v1_engine, recovery):
    importlib.reload(module)
if __name__ == '__main__':
    recovery.run(7)
