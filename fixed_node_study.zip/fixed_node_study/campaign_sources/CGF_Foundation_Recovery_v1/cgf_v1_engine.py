"""CGF bounded extension: a NEW simultaneous interface RBF-FD realization.

MATHEMATICAL COMMENTS (read before interpreting a result)
Trefftz-Herrera removes local volume information only with suitable adjoint
weight functions, the requisite TH completeness, and treatment of forcing
(e.g. local particular solutions). A finite truncated family adds approximation
error. A density concentrated near Sigma does not satisfy these conditions.
This module changes node allocation; it DOES NOT implement Trefftz-Herrera or
claim its completeness. A later weighted-functional study must be a separate
comparison. Distance-to-interface is a geometric proxy, not a Green function.

Operator adjoints here solve the transpose of a row-scaled discrete operator.
They measure sensitivity to residuals, not the derivative of error with respect
to moving nodes. Interpolation of that sensitivity to candidates is explicitly
a heuristic under test. All exact interior data enter post-solve diagnostics
only; analytic forcing and prescribed boundary values are legitimate PDE data.
Piecewise smooth manufactured states obey trace and conormal-flux continuity.
Their gradient is generally discontinuous across material interfaces.

No DDM, no coarse correction in an iteration, no claimed continuum convergence
or uniform stability theorem. The measured finite-dimensional error identity
is deeper than probability-density admissibility but is still not a theorem
uniform in node count. Existing campaigns must remain implementation-specific.
"""
import os
for _key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[_key] = '1'
import json, time, hashlib, platform
from pathlib import Path
import numpy as np
import scipy
from scipy.spatial import cKDTree
from scipy.stats import qmc
from scipy.sparse import lil_matrix, csr_matrix, diags
from scipy.sparse.linalg import splu
from numpy.polynomial.legendre import leggauss
import cgf_v1_config as C
VERSION = '1.0'


def dump(path, data):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(data, indent=2, allow_nan=False), encoding='utf-8')
    temp.replace(path)


def signature():
    raw = {k:str(v) for k,v in vars(C).items() if k.isupper()}
    raw['code'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return hashlib.sha256(json.dumps(raw,sort_keys=True).encode()).hexdigest()[:16]


def geometry(case):
    theta = np.deg2rad(case['angle']); n = np.array([np.cos(theta),np.sin(theta)])
    t = np.array([-n[1], n[0]]); center = np.array([case['cx'],case['cy']])
    hits = []
    for axis in (0,1):
        for bound in (0.,1.):
            s = (bound-center[axis])/t[axis] if abs(t[axis])>1e-12 else None
            if s is not None:
                p = center+s*t
                if np.all(p>=-1e-10) and np.all(p<=1+1e-10): hits.append(s)
    lo,hi = min(hits),max(hits)
    return n,t,center,lo,hi


def coordinates(p,case):
    n,t,c,_,_ = geometry(case)
    return (p-c)@n,(p-c)@t


def exact(p,case,side=None,load=0.):
    r,s = coordinates(np.asarray(p),case)
    k = np.where(r<=0,1.,case['contrast']) if side is None else (1. if side==0 else case['contrast'])
    w = np.pi*case['freq']; A = 1.+load
    v = A*np.sin(w*s); q = 1.+.2*np.cos(2*w*s)
    qp = -.4*w*np.sin(2*w*s); qpp = -.8*w*w*np.cos(2*w*s)
    h = r*r*np.cos(np.pi*r)
    hp = 2*r*np.cos(np.pi*r)-np.pi*r*r*np.sin(np.pi*r)
    hpp = 2*np.cos(np.pi*r)-4*np.pi*r*np.sin(np.pi*r)-np.pi**2*r*r*np.cos(np.pi*r)
    u = v + r*q/k + h*np.sin(w*s)/k
    ur = (q+hp*np.sin(w*s))/k
    us = A*w*np.cos(w*s)+(r*qp+h*w*np.cos(w*s))/k
    lap = -w*w*v + (r*qpp+(hpp-w*w*h)*np.sin(w*s))/k
    n,t,_,_,_ = geometry(case)
    grad = ur[:,None]*n+us[:,None]*t
    return u,grad,-k*lap


def boundary_segments(case):
    n,t,c,lo,hi = geometry(case)
    corners = np.array([[0.,0.],[1.,0.],[1.,1.],[0.,1.],[0.,0.]])
    normals = [[0,-1],[1,0],[0,1],[-1,0]]
    seg = []
    for a,b,norm in zip(corners[:-1],corners[1:],normals):
        ra,rb = (a-c)@n,(b-c)@n
        cuts = [0.,1.]
        if ra*rb<0: cuts.insert(1,float(-ra/(rb-ra)))
        for l,h in zip(cuts[:-1],cuts[1:]):
            aa=a+l*(b-a); bb=a+h*(b-a)
            side = int((((aa+bb)/2-c)@n)>0)
            seg.append((aa,bb,np.array(norm),side))
    return seg


def poly(p):
    x,y=p.T
    return np.column_stack([np.ones(len(p)),x,y,x*x,x*y,y*y])


def weights(nodes, point, op, count=None):
    # Local cubic polyharmonic spline with total-degree-2 augmentation.
    count=min(count or C.STENCIL,len(nodes))
    ids=cKDTree(nodes).query(point,k=count)[1]
    z=nodes[ids]-point; scale=max(np.max(np.linalg.norm(z,axis=1)),1e-12); z=z/scale
    d=np.linalg.norm(z[:,None,:]-z[None,:,:],axis=2)
    P=poly(z); M=np.block([[d**3,P],[P.T,np.zeros((6,6))]])
    rr=np.linalg.norm(z,axis=1)
    if isinstance(op,str) and op=='value': rhs=np.r_[rr**3,[1,0,0,0,0,0]]
    elif isinstance(op,str) and op=='lap': rhs=np.r_[9*rr,[0,0,0,2,0,2]]/scale**2
    else:
        direction=np.asarray(op)
        rhs=np.r_[-3*rr*(z@direction),[0,direction[0],direction[1],0,0,0]]/scale
    w=np.linalg.solve(M,rhs)[:count]
    return ids,w


def operator(model,p,op='value',sides=None):
    p=np.asarray(p); rows=lil_matrix((len(p),len(model['nodes'])))
    if sides is None: sides=(coordinates(p,model['case'])[0]>0).astype(int)
    for j,(point,side) in enumerate(zip(p,sides)):
        global_ids=model['side_ids'][int(side)]
        ids,w=weights(model['nodes'][global_ids],point,op)
        rows[j,global_ids[ids]]=w
    return rows.tocsr()


def sample_side(n,case,side,seed):
    seq=qmc.Halton(2,scramble=True,seed=seed); chunks=[]; have=0
    while have<n:
        p=seq.random(max(2*n,32)); r,_=coordinates(p,case)
        take=p[(r<=0) if side==0 else (r>0)]
        chunks.append(take);have+=len(take)
    return np.vstack(chunks)[:n]


def build(case,N,seed,method='halton',score=None):
    n,t,c,lo,hi=geometry(case); nodes=[]; kinds=[]; sides=[]
    ni=max(9,int(np.sqrt(N)*1.4)); yy=np.linspace(lo,hi,ni+2)[1:-1]
    interface=c+yy[:,None]*t
    for side in (0,1):
        boundary=[]
        for aa,bb,norm,ss in boundary_segments(case):
            if ss==side:
                nb=max(3,int(np.ceil(np.linalg.norm(bb-aa)*np.sqrt(N)*1.3)))
                boundary.extend(aa+np.linspace(0,1,nb+1)[:,None]*(bb-aa))
        boundary=np.unique(np.round(np.array(boundary),13),axis=0)
        quota=N//2 if side==0 else N-N//2
        pool=sample_side(20*quota,case,side,seed+side*101)
        fixed=np.vstack([boundary,interface]);spacing=C.MIN_SPACING_FACTOR/np.sqrt(N)
        accepted=[]
        for candidate in pool:
            cloud=np.vstack([fixed,np.array(accepted).reshape(-1,2)])
            if np.min(np.linalg.norm(cloud-candidate,axis=1))>=spacing: accepted.append(candidate)
            if len(accepted)==quota: break
        if len(accepted)!=quota: raise RuntimeError('baseline candidate coverage exhausted')
        uniform=np.array(accepted)
        if method=='halton': interior=uniform
        else:
            protected=max(6,int(np.ceil(C.PROTECTED_FRACTION*quota)))
            skeleton=uniform[:protected]
            cand=sample_side(max(20*quota,100),case,side,seed+side*101+1001)
            r,_=coordinates(cand,case)
            if method=='distance': raw=np.exp(-np.abs(r)/C.DISTANCE_WIDTH)
            else: raw=score(cand,side,method)
            if not np.all(np.isfinite(raw)): raise ValueError('nonfinite allocation score')
            raw=np.maximum(raw,0); raw=.02+raw/(np.max(raw)+1e-30)
            rng=np.random.default_rng(seed+side+811); order=np.argsort(-np.log(rng.random(len(cand)))/raw)
            chosen=list(skeleton); fixed=np.vstack([boundary,interface])
            spacing=C.MIN_SPACING_FACTOR/np.sqrt(N)
            for idx in order:
                p=cand[idx]
                cloud=np.vstack([fixed,np.array(chosen)])
                if np.min(np.linalg.norm(cloud-p,axis=1))>=spacing: chosen.append(p)
                if len(chosen)==quota: break
            if len(chosen)!=quota: raise RuntimeError('candidate coverage exhausted')
            interior=np.array(chosen)
        for pts,kind in ((interior,'pde'),(boundary,'boundary'),(interface,'interface')):
            nodes.extend(pts);kinds.extend([kind]*len(pts));sides.extend([side]*len(pts))
    nodes=np.array(nodes);sides=np.array(sides);kinds=np.array(kinds)
    model=dict(case=case,nodes=nodes,sides=sides,kinds=kinds,side_ids=[np.flatnonzero(sides==s) for s in (0,1)])
    A=lil_matrix((len(nodes),len(nodes)))
    for side in (0,1):
        gids=model['side_ids'][side]; local=nodes[gids]; k=1. if side==0 else case['contrast']
        for row in gids:
            if kinds[row]=='boundary': A[row,row]=1
            elif kinds[row]=='pde':
                ids,w=weights(local,nodes[row],'lap'); A[row,gids[ids]]=-k*w
    ii=[np.flatnonzero((sides==s)&(kinds=='interface')) for s in (0,1)]
    for left,right in zip(*ii):
        A[left,left]=1; A[left,right]=-1
        for side,row,sign in ((0,left,1),(1,right,-1)):
            gids=model['side_ids'][side];ids,w=weights(nodes[gids],nodes[row],n)
            k=1. if side==0 else case['contrast']; A[right,gids[ids]]=sign*k*w
    A=A.tocsr(); row_norm=np.asarray(abs(A).sum(axis=1)).ravel()
    if np.any(row_norm<=0): raise RuntimeError('empty equation row')
    model['scale']=1/row_norm;model['A']=diags(model['scale'])@A
    model['lu']=splu(model['A'].tocsc())
    # The objective is an independently reconstructed interface mean, not an
    # error computed from the manufactured solution during allocation.
    gx,gw=leggauss(24); pts=c+((lo+hi)/2+(hi-lo)/2*gx)[:,None]*t
    R=operator(model,pts,sides=np.zeros(len(pts),int));model['objective']=np.asarray(R.T@(gw/2)).ravel()
    return model


def solve(model,load=0.):
    p=model['nodes']; b=np.zeros(len(p)); case=model['case']
    for side in (0,1):
        ids=model['side_ids'][side];u,grad,f=exact(p[ids],case,side,load)
        for kind,data in (('pde',f),('boundary',u)):
            use=model['kinds'][ids]==kind;b[ids[use]]=data[use]
    b*=model['scale'];v=model['lu'].solve(b)
    return v,b


def pilot(case,N,seed,load=0.,need_adjoint=True):
    start=time.perf_counter();m=build(case,N,seed);v,b=solve(m,load)
    z=m['lu'].solve(m['objective'],trans='T') if need_adjoint else np.zeros(len(v))
    # Verify adjoint identity against a fixed independent residual perturbation.
    rng=np.random.default_rng(seed+91); d=rng.standard_normal(len(v))
    direct=m['objective']@m['lu'].solve(d);dual=z@d
    err=abs(direct-dual)/max(abs(direct),abs(dual),1e-14) if need_adjoint else 0.
    if err>1e-7: raise RuntimeError('adjoint duality failed')
    elapsed=time.perf_counter()-start
    def scorer(p,side,method):
        L=operator(m,p,'lap',np.full(len(p),side));k=1. if side==0 else case['contrast']
        # exact(...)[2] is the analytic prescribed source, not exact solution access.
        residual=np.abs(exact(p,case,side,load)[2]+k*(L@v))
        ids=np.flatnonzero((m['sides']==side)&(m['kinds']=='pde'))
        nearest=cKDTree(m['nodes'][ids]).query(p)[1]
        if method=='residual': return residual
        if method=='ghg_proxy':
            Dx=operator(m,p,np.array([1.,0.]),np.full(len(p),side))
            Dy=operator(m,p,np.array([0.,1.]),np.full(len(p),side))
            grad=np.hypot(Dx@v,Dy@v);r,_=coordinates(p,case)
            distance=np.exp(-np.abs(r)/C.DISTANCE_WIDTH)
            return .5*distance+.5*grad/(np.max(grad)+1e-30)
        # z is sensitivity to row-scaled residual; multiply by row scale to
        # recover sensitivity to unscaled PDE defects before spatial transfer.
        return residual*np.abs(z[ids[nearest]]*m['scale'][ids[nearest]])
    return scorer,elapsed,dict(pilot_nodes=len(v),adjoint_duality_error=err,
         adjoint_relative_residual=float(np.linalg.norm(m['A'].T@z-m['objective'])/max(np.linalg.norm(m['objective']),1e-30)) if need_adjoint else None)


def gauss_segment(aa,bb,order):
    x,w=leggauss(order);return aa+(x+1)[:,None]/2*(bb-aa), w*np.linalg.norm(bb-aa)/2


def source_integral(case,order,load):
    # Integrate material polygons by triangle quadrature via a Duffy map.
    x,w=leggauss(order);v=(x+1)/2;w=w/2;total=absolute=0.
    for side in (0,1):
        verts=[]
        for aa,bb,norm,ss in boundary_segments(case):
            if ss==side: verts.extend([aa,bb])
        verts=np.unique(np.round(verts,12),axis=0);center=verts.mean(axis=0)
        ang=np.arctan2(verts[:,1]-center[1],verts[:,0]-center[0]);verts=verts[np.argsort(ang)]
        vv,tt=np.meshgrid(v,v,indexing='ij');ww=np.outer(w,w).ravel()
        for aa,bb in zip(verts,np.roll(verts,-1,axis=0)):
            p=center+vv.ravel()[:,None]*((1-tt.ravel())[:,None]*(aa-center)+tt.ravel()[:,None]*(bb-center))
            jac=abs(np.linalg.det(np.column_stack([aa-center,bb-center])))*vv.ravel()
            f=exact(p,case,side,load)[2];total+=np.dot(ww*jac,f);absolute+=np.dot(ww*jac,np.abs(f))
    return float(total),float(absolute)


def diagnostics(m,v,b,load=0.):
    start=time.perf_counter();case=m['case'];ng=C.EVALUATION_GRID
    x=np.linspace(.015,.985,ng);xx,yy=np.meshgrid(x,x);p=np.column_stack([xx.ravel(),yy.ravel()])
    R=operator(m,p);truth=exact(p,case,load=load)[0];field=R@v
    norm=max(np.sqrt(np.mean(truth**2)),1e-12)
    bulk=float(np.sqrt(np.mean((truth-field)**2))/norm)
    r,s=coordinates(p,case);collar=np.abs(r)<.08
    collar_rel=float(np.sqrt(np.mean((truth[collar]-field[collar])**2))/max(np.sqrt(np.mean(truth[collar]**2)),1e-12))
    n,t,c,lo,hi=geometry(case);xg,wg=leggauss(64);pp=c+((lo+hi)/2+(hi-lo)*xg/2)[:,None]*t
    R0=operator(m,pp,sides=np.zeros(len(pp),int));R1=operator(m,pp,sides=np.ones(len(pp),int))
    trace=exact(pp,case,0,load)[0];tr0=R0@v;tr1=R1@v
    trace_rel=float(np.sqrt(np.dot(wg,(tr0-trace)**2)/2)/max(np.sqrt(np.dot(wg,trace**2)/2),1e-12))
    objective_error=float(abs(m['objective']@v-np.dot(wg,trace)/2))
    D0=operator(m,pp,n,np.zeros(len(pp),int));D1=operator(m,pp,n,np.ones(len(pp),int))
    flux0=D0@v;flux1=case['contrast']*(D1@v)
    flux_jump=float(np.sqrt(np.dot(wg,(flux0-flux1)**2)/2)/max(np.sqrt(np.dot(wg,flux0**2)/2),1e-12))
    history=[]
    for order in C.QUADRATURE_ORDERS:
        src,srcabs=source_integral(case,order,load); numerical_flux=exact_flux=fluxabs=0.
        for aa,bb,normdir,side in boundary_segments(case):
            qp,qw=gauss_segment(aa,bb,order);k=1. if side==0 else case['contrast']
            D=operator(m,qp,normdir,np.full(len(qp),side));fnum=-k*(D@v)
            g=exact(qp,case,side,load)[1];fexact=-k*(g@normdir)
            numerical_flux+=np.dot(qw,fnum);exact_flux+=np.dot(qw,fexact);fluxabs+=np.dot(qw,np.abs(fnum))
        den=max(srcabs+fluxabs,1e-12);defect=abs(numerical_flux-src)
        history.append(dict(order=order,source=src,source_abs=srcabs,flux=float(numerical_flux),
          exact_balance_abs=float(abs(exact_flux-src)),balance_abs=float(defect),balance_scaled=float(defect/den),
          normalization=float(den),legacy_source_relative=float(defect/max(abs(src),1e-12))))
    high=history[-1];low=history[-2]
    qchange=abs(high['flux']-low['flux'])/high['normalization']+abs(high['source']-low['source'])/high['normalization']
    # Exact nodal comparator enters ONLY here, after construction and solve.
    cv=np.empty(len(v))
    for side in (0,1):
        ids=m['side_ids'][side];cv[ids]=exact(m['nodes'][ids],case,side,load)[0]
    tau=m['A']@cv-b;correction=m['lu'].solve(tau)
    exact_nodal_flux_jump=D0@cv-case['contrast']*(D1@cv)
    exact_flux_reference=exact(pp,case,0,load)[1]@n
    flux_reconstruction_jump=float(np.sqrt(np.dot(wg,exact_nodal_flux_jump**2)/2)/max(np.sqrt(np.dot(wg,exact_flux_reference**2)/2),1e-12))
    reconstruction=truth-R@cv;consistency=R@correction
    identity=float(np.max(np.abs((truth-field)-(reconstruction+consistency))))
    # A computable finite-system upper bound in infinity norm, not uniform-N theory.
    # Full inverse is restricted to small systems; larger systems retain the exact
    # error identity but do not mislabel a random probe as an upper bound.
    bound=None;inv_norm=None
    if len(v)<=350:
        inverse=m['lu'].solve(np.eye(len(v)));inv_norm=float(np.max(np.sum(np.abs(inverse),axis=1)))
        rnorm=float(np.max(np.asarray(abs(R).sum(axis=1))))
        bound=float(np.max(np.abs(reconstruction))+rnorm*inv_norm*np.max(np.abs(tau)))
    gaps=[];seps=[]
    for side in (0,1):
        ids=m['side_ids'][side];tree=cKDTree(m['nodes'][ids]);mask=(r<=0) if side==0 else (r>0)
        gaps.append(float(np.max(tree.query(p[mask])[0])))
        seps.append(float(np.min(tree.query(m['nodes'][ids],k=2)[0][:,1])))
    node_iface=np.flatnonzero((m['sides']==0)&(m['kinds']=='interface'))
    ip=m['nodes'][node_iface]
    nodeflux0=operator(m,ip,n,np.zeros(len(ip),int))@v
    nodeflux1=case['contrast']*(operator(m,ip,n,np.ones(len(ip),int))@v)
    node_flux_jump=float(np.max(np.abs(nodeflux0-nodeflux1))/max(np.max(np.abs(nodeflux0)),1e-12))
    result=dict(flux_reconstruction_jump_from_exact_nodes_relative=flux_reconstruction_jump,interface_node_flux_jump_relative=node_flux_jump,bulk_relative=bulk,collar_relative=collar_rel,interface_relative=trace_rel,
      objective_abs_error=objective_error,trace_jump_max=float(np.max(np.abs(tr0-tr1))),flux_jump_relative=flux_jump,
      balance_scaled=high['balance_scaled'],balance_abs=high['balance_abs'],quadrature_change_scaled=float(qchange),
      exact_balance_abs=high['exact_balance_abs'],source_relative_balance=high['legacy_source_relative'],
      algebraic_relative=float(np.linalg.norm(m['A']@v-b)/max(np.linalg.norm(b),1e-30)),
      nodal_consistency_inf=float(np.max(np.abs(tau))),reconstruction_inf=float(np.max(np.abs(reconstruction))),
      consistency_response_inf=float(np.max(np.abs(consistency))),field_error_inf=float(np.max(np.abs(truth-field))),
      decomposition_identity_error=identity,discrete_inf_bound=bound,inverse_inf_norm=inv_norm,
      fill_distance_grid=max(gaps),minimum_separation=min(seps),total_unknowns=len(v),
      quadrature_history=history,diagnostic_seconds=time.perf_counter()-start)
    result['qualified']=bool(trace_rel<=C.INTERFACE_REL_TOL and bulk<=C.BULK_REL_TOL and
       high['balance_scaled']<=C.BALANCE_TOL and flux_jump<=C.FLUX_JUMP_TOL and qchange<=C.QUADRATURE_TOL and result['algebraic_relative']<=1e-8)
    return result


def run_case(folder,case,N,seed,method,load=0.,reuse=None,shared_target=None):
    key=f"{case['name']}_N{N}_s{seed}_{method}_load{load:g}";path=folder/key
    receipt=path/'receipt.json'
    if receipt.exists():
        old=json.loads(receipt.read_text())
        if old.get('signature')==signature() and old.get('status')=='complete': return old
    path.mkdir(parents=True,exist_ok=True)
    print('RUN',key,flush=True);start=time.perf_counter();info={};pilot_seconds=0.
    try:
        score=None
        if method in ('adjoint_full','adjoint_coarse','residual','adjoint_reuse','ghg_proxy'):
            if reuse is not None: score,pilot_seconds,info=reuse
            else:
                pn=C.PILOT_BUDGET*(C.FULL_PILOT_MULTIPLIER if method=='adjoint_full' else 1)
                score,pilot_seconds,info=pilot(case,pn,seed,load,need_adjoint=method not in ('residual','ghg_proxy'))
        allocation_start=time.perf_counter()
        if shared_target is None:
            m=build(case,N,seed,'halton' if method=='halton_reuse' else method,score)
            v,b=solve(m,load);target_seconds=time.perf_counter()-allocation_start
        else:
            m,setup_share=shared_target;v,b=solve(m,load)
            target_seconds=setup_share+time.perf_counter()-allocation_start
            info=dict(info,target_factorization_reused=True,target_setup_share_seconds=setup_share)
        diag=diagnostics(m,v,b,load)
        row=dict(signature=signature(),status='complete',case=case['name'],case_parameters=case,
          budget=N,seed=seed,method=method,load=load,pilot_seconds=pilot_seconds,
          target_setup_solve_seconds=target_seconds,charged_seconds=pilot_seconds+target_seconds,
          timing_scope='pilot including scoring setup + scoring + target assembly/factorization/solve; offline exact diagnostics and IO excluded',**info,**diag)
        np.savez_compressed(path/'state.npz',nodes=m['nodes'],sides=m['sides'],kinds=m['kinds'],solution=v,
            rhs=b,objective=m['objective'],A_data=m['A'].data,A_indices=m['A'].indices,A_indptr=m['A'].indptr,A_shape=m['A'].shape)
    except Exception as exc:
        row=dict(signature=signature(),status='failed',case=case['name'],budget=N,seed=seed,method=method,
                 load=load,error=f'{type(exc).__name__}: {exc}',elapsed_seconds=time.perf_counter()-start)
    dump(receipt,row);print(row['status'],row.get('bulk_relative'),row.get('balance_scaled'),flush=True)
    return row


def write_csv(path,rows):
    import csv
    if not rows: return
    keys=sorted(set().union(*(r.keys() for r in rows)))
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader()
        for row in rows: w.writerow({k:json.dumps(v) if isinstance(v,(dict,list)) else v for k,v in row.items()})


def run_branch(branch):
    from threadpoolctl import threadpool_limits
    # threadpool_limits also works when Spyder has imported NumPy before this script.
    with threadpool_limits(limits=1): return _run_branch(branch)


def _run_branch(branch):
    folder=C.OUTPUT_ROOT/{1:'01_foundation',2:'02_sensitivity',3:'03_cost_holdout'}[branch]
    folder.mkdir(parents=True,exist_ok=True)
    budgets=[60,100] if C.PROFILE=='smoke' else C.BUDGETS
    seeds=[11] if C.PROFILE=='smoke' else C.SEEDS
    cases=C.TRAIN if branch<3 else C.HOLDOUT
    if C.PROFILE=='smoke': cases=cases[:1]
    rows=[]
    if branch>1:
        previous=C.OUTPUT_ROOT/{2:'01_foundation',3:'02_sensitivity'}[branch]/'completion.json'
        if not previous.exists(): raise RuntimeError(f'Run branch {branch-1} first')
        prior=json.loads(previous.read_text())
        if prior['signature']!=signature(): raise RuntimeError('Configuration changed; rerun predecessor')
        foundation_path=C.OUTPUT_ROOT/'01_foundation/completion.json'
        foundation=json.loads(foundation_path.read_text())
        if not foundation['foundation_pass'] and not C.ALLOW_DESCRIPTIVE_CONTINUATION:
            raise RuntimeError('Foundation scientific gate failed. Review branch 1 first. For explicitly descriptive diagnosis only, set ALLOW_DESCRIPTIVE_CONTINUATION=True and rerun branch 1 with the changed configuration.')
    methods={1:['halton'],2:['halton','distance','ghg_proxy','residual','adjoint_full','adjoint_coarse'],
             3:['halton','halton_reuse','distance','ghg_proxy','residual','adjoint_coarse','adjoint_reuse']}[branch]
    for case in cases:
        for seed in seeds:
            reuse=None
            if branch==3:
                # Reuse sensitivity AND a source-specific score from load=0 as a
                # frozen policy across loads; this can fail and is reported as such.
                raw=pilot(case,C.PILOT_BUDGET,seed,0.)
                reuse=(raw[0],raw[1]/2,dict(raw[2],reuse_setup_total_seconds=raw[1],reuse_load_count=2))
            for N in budgets:
                for method in methods:
                    loads=[0.,.25] if branch==3 else [0.]
                    shared=None
                    if branch==3 and method in ('halton_reuse','adjoint_reuse'):
                        tm=time.perf_counter()
                        cached=build(case,N,seed,'halton' if method=='halton_reuse' else method,reuse[0] if method=='adjoint_reuse' else None)
                        shared=(cached,(time.perf_counter()-tm)/len(loads))
                    for load in loads:
                        rows.append(run_case(folder,case,N,seed,method,load,reuse if method=='adjoint_reuse' else None,shared))
            if branch==3:
                for N in sorted({int(np.ceil(max(budgets)*f)) for f in C.AFFORDABLE_HALTON_MULTIPLIERS}):
                    for load in (0.,.25): rows.append(run_case(folder,case,N,seed,'halton',load))
    write_csv(folder/'case_table.csv',rows)
    completed=[r for r in rows if r['status']=='complete'];failed=[r for r in rows if r['status']!='complete']
    summary=dict(signature=signature(),branch=branch,profile=C.PROFILE,cases=len(rows),completed=len(completed),
       failures=len(failed),qualified=sum(r['qualified'] for r in completed),status='complete' if not failed else 'completed_with_failures',
       environment=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__))
    if branch==1:
        # Gate is inspected at the highest budget for each training configuration/seed.
        top=[r for r in completed if r['budget']==max(budgets)]
        summary['foundation_pass']=bool(not failed and top and all(r['qualified'] for r in top))
    dump(folder/'completion.json',summary)
    if branch==3: adjudicate(folder,rows)
    print('Branch finished:',summary,flush=True)
    return summary


def adjudicate(folder,rows):
    # All comparisons are per case/seed/load. A repeated seed over budgets is
    # not an independent replicate. No pooled p-values are manufactured here.
    foundation=json.loads((C.OUTPUT_ROOT/'01_foundation/completion.json').read_text())
    sensitivity=json.loads((C.OUTPUT_ROOT/'02_sensitivity/completion.json').read_text())
    groups={}
    for row in rows:
        if row['status']=='complete': groups.setdefault((row['case'],row['seed'],row['load']),[]).append(row)
    comparisons=[]
    for key,rr in groups.items():
        for method in sorted({r['method'] for r in rr}):
            hits=[r for r in rr if r['method']==method and r['qualified']]
            if not hits:
                comparisons.append(dict(case=key[0],seed=key[1],load=key[2],method=method,status='target_not_attained'));continue
            best=min(hits,key=lambda r:r['charged_seconds'])
            cheaper=[r for r in rr if r['method'] in ('halton','halton_reuse') and r['charged_seconds']<=best['charged_seconds']]
            base=min(cheaper,key=lambda r:r['interface_relative']) if cheaper else None
            comparisons.append(dict(case=key[0],seed=key[1],load=key[2],method=method,status='target_attained',
              attained_budget=best['budget'],cost_seconds=best['charged_seconds'],interface_relative=best['interface_relative'],
              affordable_halton_budget=base['budget'] if base else None,
              affordable_halton_interface_relative=base['interface_relative'] if base else None,
              affordable_halton_qualified=base['qualified'] if base else None))
    write_csv(folder/'cost_to_accuracy.csv',comparisons)
    dump(folder/'adjudication.json',dict(signature=signature(),foundation_pass=foundation['foundation_pass'],
      pooled_claim_allowed=bool(foundation['foundation_pass'] and sensitivity['failures']==0 and C.PROFILE=='production' and all(r['status']=='complete' for r in rows)),
      interpretation='No universal superiority verdict. Inspect paired attainment and affordable Halton outcomes; failures retained.',
      finite_budget_limit='If no affordable Halton budget reaches the informed cost, extend Halton budgets; do not extrapolate a victory.'))
