"""Run with F5 in Spyder. Outputs remain separate from prior campaigns."""
from pathlib import Path
import sys, importlib
HERE=Path(__file__).resolve().parent
if str(HERE) not in sys.path: sys.path.insert(0,str(HERE))
import config, engine
importlib.reload(config)
importlib.reload(engine)
if __name__=='__main__':engine.run_branch(2)
