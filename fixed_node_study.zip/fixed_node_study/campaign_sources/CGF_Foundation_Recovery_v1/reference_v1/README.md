# CGF bounded extension v1

Purpose: explain when interface concentration helps, when it fails, and whether
operator sensitivity earns its cost. Preserve the submitted CAMWA manuscript.
This is a new simultaneous RBF-FD realization, not a replay of earlier archives
and not an implementation of the Trefftz-Herrera method.

## Install and run in Spyder

Extract this entire folder under:
`/home/dakini/Downloads/012-MADV_AOT_collocation/CGF_Bounded_Extension_v1`

Dependencies: Python 3.10+, NumPy, SciPy, threadpoolctl. For evidence PDF text,
install Poppler (pdftotext) or pypdf. No automatic installation, network calls,
external script execution or command-line arguments are required.

Run each script with F5, in this order:

1. `00_Evidence_Recovery_Spyder.py`: read-only project-wide search, including ZIP
   member texts and CSV tables. Read `scan_limits_and_errors.csv` before treating
   a negative search as absence. Nested ZIPs and archived PDFs are inventoried
   but not opened; oversized members and tables are explicitly flagged.
2. `04_Verification_Spyder.py`: independent numerical identities.
3. `01_Foundation_Spyder.py`: simultaneous solves and conservation diagnostics.
4. `02_Sensitivity_Spyder.py`: distance, GHG proxy, residual and full/coarse
   discrete sensitivity comparisons, with reconstruction and consistency error.
5. `03_Cost_Holdout_Spyder.py`: frozen policy on unseen oblique interfaces,
   contrasts and source frequencies; two right-hand sides; affordable larger
   Halton and baseline factorization reuse.

All settings are at the top of `config.py`. Default is the production profile.
For a short plumbing check, set PROFILE='smoke'. Smoke outcomes never authorize
publication claims. Before returning to production, restore the profile and run
all numerical branches; a changed configuration invalidates old receipts.

Outputs are in one common folder `CGF_Bounded_Extension_v1_outputs`, with a
separate subfolder per branch and per case. Existing project evidence and the
submitted paper are never edited. Completed cases resume when code/configuration
match; failed cases are retried. Incomplete predecessor stages block later ones.
Scientific failures block later branches by default. After reviewing branch 1,
ALLOW_DESCRIPTIVE_CONTINUATION=True permits explanatory experiments only; rerun
branch 1 with that setting so all branches share the same protocol. Pooled
performance claims remain blocked.
If the foundation fails, return its outputs for analysis before proceeding.
Run the scripts serially; they are not designed for concurrent instances.

## What to return for analysis

ZIP the output folder after all required branches finish, including state.npz,
receipt.json, completion.json, case_table.csv, candidate_pairs.csv,
known_manuscript_coverage.csv, scan_limits_and_errors.csv, cost_to_accuracy.csv
and adjudication.json. No victory is assigned automatically to GHG.
If foundation_pass is false, the immediate task is to explain/repair the
foundation; holdout outcomes remain descriptive. The default 480-node gate is
not guaranteed to pass. Do not relax it retrospectively to force a pass.

## Historical evidence and potential omissions

The included known manuscript ledger records gains already present in the
submitted PDF: earlier static training gains, Green/floor ablations, organized
collars and adjoint-only weighting. Root-level search creates NEW candidate
pairs and quotations; it does not prove omitted results. Column inference is
conservative, but an apparently unique pair can still differ in load, engine,
evaluation or protocol. Those dimensions require manual scientific review.
Candidate rows are not independent when duplicated across an extracted folder
and ZIP archive. Do not pool them or count them twice.

Exact interior states do not influence allocation. A manufactured state is
used only for post-solve errors and consistency diagnostics; its forcing and
boundary values are supplied as legitimate PDE data.
