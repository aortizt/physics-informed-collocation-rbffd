# Mathematical diagnosis

## The original finite system

Let A be the original row-scaled square collocation matrix, b its right-hand
side, v its computed solution, c the exact nodal values, and R the independent
field reconstruction. Define tau=A c-b and delta=A^(-1) tau. Up to floating
point error:

    c-v = delta
    u-R v = (u-R c) + R delta.

The first term measures reconstruction of exact nodal information. The second
is the consistency defect propagated by the discrete solve. Stage 06 splits
tau among left PDE, right PDE, boundary, trace and conormal-flux rows. It
reports each propagated field and flux contribution. Their norms cannot be
added as attribution percentages: components may cancel.

For the one-sided conormal derivative difference J=D_left-K_right D_right,

    J v = J c - J delta.

All three flux terms in this decomposition use the SAME exact-flux RMS
normalization. This matters because v1's qualification metric normalizes
the numerical jump by the computed left flux; its exact-nodal comparator
uses the exact flux. Their reported percentages cannot otherwise be subtracted.

Singular values and modal projections refer to the declared row-scaled A.
If A=U S V^T, delta=V S^(-1) U^T tau. Small singular values can amplify
the corresponding consistency components. Measured condition numbers depend
on the scaling and finite system; they do not prove uniform stability,
continuum convergence, or that roundoff is the source of the error.

## Experimental constrained least squares

Write v=g+T y, where g inserts prescribed exterior Dirichlet values and T
shares each paired interface trace unknown. PDE and conormal equations are
retained at the original locations; the declared arms append independent
equations at extra evaluation points. Nodes and number of unknowns do not
change between these arms.

Each equation is divided by the l1 norm of its full coefficient row, before
constraint elimination. Within each of three groups (left PDE, right PDE,
flux), rows receive another factor 1/sqrt(number of equations in that group).
Let H and f denote the assembled normalized equations. The problem is

    minimize_y || H T y - (f-H g) ||_2.

The solver is a dense SVD with the library's default rank criterion, recorded
by rank and singular-value condition ratio. Stationarity is normalized as

    ||B^T(B y-d)||_2 / [s_max (s_max ||y||_2 + ||d||_2)],

where B=H T and d=f-H g. Rank loss blocks the solver screen. There is no
post-hoc choice of regularization or weights based on exact interior error.

The square-system error decomposition above does not apply unchanged to an
LS solution. The original square diagnostic fields that would misstate that
identity or its bound are removed from LS receipts. Physical error, original
equation residual, rank, constraints and stationarity are reported separately.
In LS `state.npz`, A and rhs denote the reference square operator. The LS
operator is reproduced from source, the saved node layout, seed and arm; that
stored square A does not assert A v=b for an LS solution.

The ls_nodal arm has no new observations and controls for changing the solver
and constraint treatment. Compare ls_flux, ls_pde and ls_both with ls_nodal.
The wider-stencil square arm isolates a different change. Do not attribute
a combined-arm improvement to node allocation: node positions are fixed.

## Physical checks and limits

Original limits: trace relative L2 2%; bulk relative RMS 5%; normalized global
balance 5%; interface flux jump 5%; quadrature-change scale 0.5%; square
algebraic residual 1e-8. The original 64-point Gauss flux diagnostic remains.
A separate 257-point midpoint diagnostic checks flux between enforced nodes.
Two samplings do not prove a continuum supremum bound or quadrature convergence.

All experiments use the original vertical-interface manufactured problem,
three budgets, and three seeds. They are discovery/training experiments.
Higher resolution, fresh seeds, changed interfaces and costs require a later
frozen validation protocol. No old scientific gate is overridden here.

## Relation to Martin Diaz Viera's dissertation

Interface reduction in a Trefftz-Herrera construction depends on appropriate
weight functions, completeness, and treatment of local forcing. Truncated
families add approximation error. The present experiment neither supplies
those conditions nor reduces the PDE to interface-only data. It keeps volume
forcing explicit. Extra equation sampling changes what the discrete solve
enforces; putting more nodes near an interface alone supplies no completeness
or accuracy guarantee. The original protocol discussion is included under
`reference_v1/MATHEMATICAL_PROTOCOL.md`.

## Related primary literature

I. Tominec, E. Larsson, A. Heryudono, *A Least Squares Radial Basis Function
Finite Difference Method with Improved Stability Properties*, SIAM Journal
on Scientific Computing (2021), DOI 10.1137/20M1320079.
https://arxiv.org/abs/2003.03132

This paper motivates examining least-squares enforcement. The constrained
interface experiment here differs in formulation and weighting; its published
analysis is not claimed to cover this implementation.
