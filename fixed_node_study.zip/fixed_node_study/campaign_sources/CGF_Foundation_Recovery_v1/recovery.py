"""Foundation investigation; no command-line arguments, no automatic promotion.

The original source and evidence are bundled. The v1 implementation is used
only for its declared PDE, nodes, operators and existing physical diagnostics.
This study is not Trefftz-Herrera: no adjoint-complete weight family or volume
elimination is constructed. Local forcing remains explicitly represented.
Changing equation sampling is a different operation from changing node density.
"""
import os
for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[key] = '1'
import csv
import hashlib
import json
import platform
import time
import traceback
import zipfile
from pathlib import Path
import numpy as np
import scipy
from scipy.linalg import lstsq, svd
from scipy.sparse import csr_matrix, diags, vstack
from scipy.sparse.linalg import splu
from threadpoolctl import threadpool_limits
import cgf_v1_config as C
import cgf_v1_engine as E
import recovery_config as K

GATES = dict(interface_relative=C.INTERFACE_REL_TOL,
             bulk_relative=C.BULK_REL_TOL, balance_scaled=C.BALANCE_TOL,
             flux_jump_relative=C.FLUX_JUMP_TOL,
             quadrature_change_scaled=C.QUADRATURE_TOL, algebraic_relative=1e-8)

def signature():
    h = hashlib.sha256()
    for p in sorted(K.HERE.glob('*.py')):
        h.update(p.name.encode()); h.update(p.read_bytes())
    for p in sorted(K.EVIDENCE_ROOT.rglob('*')):
        if p.is_file(): h.update(p.relative_to(K.EVIDENCE_ROOT).as_posix().encode()); h.update(p.read_bytes())
    h.update(repr((scipy.__version__,np.__version__)).encode())
    return h.hexdigest()

def cases():
    paths = sorted((K.EVIDENCE_ROOT/'01_foundation').glob('*/receipt.json'))
    rows = [(p, json.loads(p.read_text())) for p in paths]
    expected = {(n,s) for n in C.BUDGETS for s in C.SEEDS}
    actual = {(r['budget'],r['seed']) for _,r in rows}
    if len(rows)!=9 or actual!=expected or any(r['status']!='complete' for _,r in rows):
        raise RuntimeError('Expected all nine completed original foundation cases.')
    return sorted(rows,key=lambda pr:(pr[1]['seed'],pr[1]['budget']))

def state(path,row):
    with np.load(path.parent/'state.npz',allow_pickle=False) as f:
        a={k:f[k].copy() for k in f.files}
    A=csr_matrix((a['A_data'],a['A_indices'],a['A_indptr']),shape=tuple(a['A_shape']))
    m=dict(case=row['case_parameters'],nodes=a['nodes'],sides=a['sides'],kinds=a['kinds'],
           A=A,lu=splu(A.tocsc()),objective=a['objective'])
    m['side_ids']=[np.flatnonzero(m['sides']==s) for s in (0,1)]
    return m,a['solution'],a['rhs']

def reference_values(m):
    cv=np.empty(len(m['nodes']))
    for s in (0,1):
        ids=m['side_ids'][s];cv[ids]=E.exact(m['nodes'][ids],m['case'],s)[0]
    return cv

def evaluation(m):
    x=np.linspace(.015,.985,C.EVALUATION_GRID); xx,yy=np.meshgrid(x,x)
    p=np.column_stack([xx.ravel(),yy.ravel()]); R=E.operator(m,p)
    return R,E.exact(p,m['case'])[0]

def interface_operator(m,points=64):
    n,t,c,lo,hi=E.geometry(m['case'])
    if points==64:
        x,w=np.polynomial.legendre.leggauss(64);s=(lo+hi)/2+(hi-lo)*x/2;w=w/2
    else:
        # Midpoints avoid endpoints and are distinct from collocation nodes.
        s=lo+(hi-lo)*(np.arange(points)+.5)/points;w=np.full(points,1/points)
    p=c+s[:,None]*t
    D0=E.operator(m,p,n,np.zeros(len(p),int))
    D1=m['case']['contrast']*E.operator(m,p,n,np.ones(len(p),int))
    ref=E.exact(p,m['case'],0)[1]@n
    return p,w,D0,D1,ref

def weighted_norm(x,w): return float(np.sqrt(w@(x*x)))

def gate_rows(row,arm=None):
    out=[]
    for name,tol in GATES.items():
        val=float(row[name]);out.append(dict(budget=row['budget'],seed=row['seed'],
           arm=arm or row.get('arm','original'),criterion=name,value=val,threshold=tol,
           passes=bool(np.isfinite(val) and val<=tol)))
    return out

def write_table(path,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    if rows:E.write_csv(path,rows)

def run_cached(folder,key,sig,fn):
    dest=folder/key;receipt=dest/'receipt.json'
    if receipt.exists():
        old=json.loads(receipt.read_text())
        if old.get('signature')==sig and old.get('status')=='complete':
            print('RESUME',key,flush=True);return old
    dest.mkdir(parents=True,exist_ok=True);print('RUN',key,flush=True)
    start=time.perf_counter()
    try:
        row=fn(dest);row.update(status='complete',signature=sig,elapsed_seconds=time.perf_counter()-start)
    except Exception as exc:
        row=dict(status='failed',signature=sig,key=key,error=f'{type(exc).__name__}: {exc}')
        (dest/'error.txt').write_text(traceback.format_exc())
    E.dump(receipt,row);print(row['status'],key,flush=True);return row

def diagnose_one(path,row,dest):
    C.STENCIL=25;m,v,b=state(path,row);R,truth=evaluation(m);cv=reference_values(m)
    replay=m['lu'].solve(b)
    replay_error=float(np.max(np.abs(replay-v)))
    if replay_error>K.REPLAY_TOL*max(1.,np.max(np.abs(v))):
        raise RuntimeError('Saved solution cannot be reproduced from its saved system.')
    d=E.diagnostics(m,v,b)
    difference=max(abs(float(d[k])-float(row[k])) for k in GATES)
    if difference>K.REPLAY_TOL:raise RuntimeError('Original diagnostic replay mismatch.')
    tau=m['A']@cv-b;delta=m['lu'].solve(tau)
    reconstruction=truth-R@cv;propagation=R@delta
    kinds=m['kinds'];sides=m['sides']
    groups={'pde_left':(kinds=='pde')&(sides==0),'pde_right':(kinds=='pde')&(sides==1),
            'boundary':kinds=='boundary','trace':(kinds=='interface')&(sides==0),
            'flux':(kinds=='interface')&(sides==1)}
    p,w,D0,D1,ref=interface_operator(m);J=D0-D1
    refnorm=max(weighted_norm(ref,w),1e-12);jump=J@v
    contributions=[]
    for name,mask in groups.items():
        t=np.where(mask,tau,0.);response=m['lu'].solve(t)
        contributions.append(dict(block=name,scaled_consistency_inf=float(np.max(np.abs(t))),
            field_response_inf=float(np.max(np.abs(R@response))),
            flux_response_ref_relative=weighted_norm(J@response,w)/refnorm))
    # Block norms are not additive attribution percentages: cancellation is possible.
    write_table(dest/'consistency_by_equation.csv',contributions)
    U,s,Vh=svd(m['A'].toarray(),full_matrices=False)
    modal=(U.T@tau)/s
    mode_rows=[dict(smallest_mode_rank=i+1,singular_value=float(s[-1-i]),
                   defect_projection=float((U.T@tau)[-1-i]),
                   response_coefficient=float(modal[-1-i])) for i in range(min(10,len(s)))]
    write_table(dest/'small_singular_modes.csv',mode_rows)
    samples=[dict(x=float(pp[0]),y=float(pp[1]),flux_left=float(a),flux_right=float(bb),
      exact_flux=float(rr),jump=float(j),exact_nodal_jump=float(jc),propagated_jump=float(jd))
      for pp,a,bb,rr,j,jc,jd in zip(p,D0@v,D1@v,ref,jump,J@cv,J@delta)]
    write_table(dest/'interface_flux_samples.csv',samples)
    out=dict(budget=row['budget'],seed=row['seed'],**d,
       replay_solution_inf=replay_error,replay_metric_max_difference=difference,
       scaled_matrix_condition_2=float(s[0]/s[-1]),smallest_singular_value=float(s[-1]),
       field_propagation_gain=float(np.max(np.abs(propagation))/max(np.max(np.abs(tau)),1e-300)),
       nodal_error_identity_inf=float(np.max(np.abs((cv-v)-delta))),
       flux_identity_inf=float(np.max(np.abs(jump-(J@cv-J@delta)))),
       flux_jump_exact_reference_relative=weighted_norm(jump,w)/refnorm,
       flux_reconstruction_exact_reference_relative=weighted_norm(J@cv,w)/refnorm,
       flux_propagation_exact_reference_relative=weighted_norm(J@delta,w)/refnorm,
       smallest10_response_energy_fraction=float(np.sum(modal[-10:]**2)/max(np.sum(modal**2),1e-300)))
    out['failed_criteria']=[r['criterion'] for r in gate_rows(out) if not r['passes']]
    return out

def stage06():
    sig=signature();folder=K.OUTPUT_ROOT/'06_archive_diagnosis';rows=[]
    with threadpool_limits(limits=1):
        for path,row in cases():
            key=path.parent.name
            rows.append(run_cached(folder,key,sig,lambda dest,p=path,r=row:diagnose_one(p,r,dest)))
    write_table(folder/'case_table.csv',rows)
    write_table(folder/'gate_failures.csv',[g for r in rows if r['status']=='complete' for g in gate_rows(r)])
    result=dict(status='complete' if all(r['status']=='complete' for r in rows) else 'completed_with_failures',
                cases=len(rows),completed=sum(r['status']=='complete' for r in rows),signature=sig)
    E.dump(folder/'completion.json',result);print(result,flush=True)

def reduced_constraints(m):
    """u=g+T y enforces exterior Dirichlet data and nodal interface traces exactly."""
    kinds=m['kinds'];sides=m['sides'];n=len(kinds);g=np.zeros(n)
    boundary=np.flatnonzero(kinds=='boundary')
    for side in (0,1):
        ids=boundary[sides[boundary]==side]
        # Only prescribed boundary values, never interior exact values.
        g[ids]=E.exact(m['nodes'][ids],m['case'],side)[0]
    ids=list(np.flatnonzero(kinds=='pde'))
    left=np.flatnonzero((kinds=='interface')&(sides==0))
    right=np.flatnonzero((kinds=='interface')&(sides==1))
    rr=ids.copy();cc=list(range(len(ids)));offset=len(ids)
    for j,(a,b) in enumerate(zip(left,right)):
        rr.extend([int(a),int(b)]);cc.extend([offset+j,offset+j])
    T=csr_matrix((np.ones(len(rr)),(rr,cc)),shape=(n,len(ids)+len(left)))
    return g,T

def ls_solve(m,b,arm,seed):
    """A declared constrained least-squares experiment, not a published-method replay.

    Use original row-scaled PDE and flux rows. Append independent evaluation
    equations, each scaled by its full-row l1 norm. Give left PDE, right PDE,
    and flux groups equal mean-square weight. Nodal traces and boundary values
    remain exact through variable elimination. Solve with dense SVD, not normal
    equations. The exact interior state is unavailable to this function.
    """
    kinds=m['kinds'];sides=m['sides'];case=m['case'];blocks=[];rhs=[]
    for side in (0,1):
        ids=np.flatnonzero((kinds=='pde')&(sides==side));B=m['A'][ids];bb=b[ids]
        if arm in ('ls_pde','ls_both'):
            pp=E.sample_side(K.EXTRA_PDE_PER_INTERIOR*len(ids),case,side,seed+50000+101*side)
            k=1. if side==0 else case['contrast']
            H=-k*E.operator(m,pp,'lap',np.full(len(pp),side))
            scale=1/np.asarray(abs(H).sum(axis=1)).ravel()
            H=diags(scale)@H;hb=scale*E.exact(pp,case,side)[2]
            B=vstack([B,H]).tocsr();bb=np.r_[bb,hb]
        blocks.append(B/np.sqrt(B.shape[0]));rhs.append(bb/np.sqrt(B.shape[0]))
    ids=np.flatnonzero((kinds=='interface')&(sides==1));B=m['A'][ids];bb=b[ids]
    if arm in ('ls_flux','ls_both'):
        n,t,c,lo,hi=E.geometry(case);count=K.EXTRA_INTERFACE_FACTOR*len(ids)
        ss=lo+(hi-lo)*(np.arange(count)+.5)/count;pp=c+ss[:,None]*t
        H=E.operator(m,pp,n,np.zeros(count,int))-case['contrast']*E.operator(m,pp,n,np.ones(count,int))
        scale=1/np.asarray(abs(H).sum(axis=1)).ravel()
        B=vstack([B,diags(scale)@H]).tocsr();bb=np.r_[bb,np.zeros(count)]
    blocks.append(B/np.sqrt(B.shape[0]));rhs.append(bb/np.sqrt(B.shape[0]))
    H=vstack(blocks).tocsr();f=np.concatenate(rhs);g,T=reduced_constraints(m)
    B=(H@T).toarray();y_rhs=f-H@g
    y,_,rank,s=lstsq(B,y_rhs,cond=None,lapack_driver='gelsd')
    v=g+T@y;res=B@y-y_rhs
    stationarity=float(np.linalg.norm(B.T@res)/max(s[0]*(s[0]*np.linalg.norm(y)+np.linalg.norm(y_rhs)),1e-300))
    left=np.flatnonzero((kinds=='interface')&(sides==0));right=ids
    boundary=np.flatnonzero(kinds=='boundary')
    constraint=float(max(np.max(np.abs(v[boundary]-g[boundary])),np.max(np.abs(v[left]-v[right]))))
    return v,dict(ls_equations=B.shape[0],ls_unknowns=B.shape[1],ls_rank=int(rank),
       ls_full_column_rank=bool(rank==B.shape[1]),ls_condition_2=float(s[0]/s[-1]),
       ls_stationarity_relative=stationarity,ls_constraint_inf=constraint,
       ls_weighted_residual_norm=float(np.linalg.norm(res)),
       solver_checks_pass=bool(rank==B.shape[1] and stationarity<=K.SOLVER_TOL and constraint<=K.CONSTRAINT_TOL))

def control_one(path,row,arm,dest):
    # Rebuild the same nodes; changing stencil size cannot change allocation.
    C.STENCIL=37 if arm=='square37' else 25
    tm=time.perf_counter();m=E.build(row['case_parameters'],row['budget'],row['seed'])
    with np.load(path.parent/'state.npz',allow_pickle=False) as saved:
        if not np.array_equal(m['nodes'],saved['nodes']) or not np.array_equal(m['kinds'],saved['kinds']):
            raise RuntimeError('Node layout differs from archived case; matched comparison blocked.')
        original_v=saved['solution'].copy()
        saved_A=csr_matrix((saved['A_data'],saved['A_indices'],saved['A_indptr']),shape=tuple(saved['A_shape']))
    v,b=E.solve(m);extra={}
    if arm=='square25':
        err=float(np.max(np.abs(v-original_v)))
        if err>K.REPLAY_TOL*max(1.,np.max(np.abs(original_v))):raise RuntimeError('Baseline rebuild mismatch.')
        matrix_diff=m['A']-saved_A
        matrix_error=float(np.max(np.abs(matrix_diff.data))) if matrix_diff.nnz else 0.
        if matrix_error>K.REPLAY_TOL:raise RuntimeError('Baseline matrix rebuild mismatch.')
        extra.update(replay_solution_inf=err,replay_matrix_max_difference=matrix_error)
    if arm.startswith('ls_'):v,extra=ls_solve(m,b,arm,row['seed'])
    elapsed=time.perf_counter()-tm
    d=E.diagnostics(m,v,b)
    if arm.startswith('ls_'):
        # v1 error decomposition assumes a square-system solution. It is not
        # valid for a least-squares solution; never publish those v1 fields.
        for name in ('consistency_response_inf','decomposition_identity_error','discrete_inf_bound',
                     'inverse_inf_norm','nodal_consistency_inf','reconstruction_inf','qualified'):
            d.pop(name,None)
    p,w,D0,D1,ref=interface_operator(m,K.DENSE_INTERFACE_POINTS)
    jump=D0@v-D1@v;den=max(weighted_norm(D0@v,w),1e-12)
    dense=weighted_norm(jump,w)/den
    dense_ref=weighted_norm(jump,w)/max(weighted_norm(ref,w),1e-12)
    physical=all(np.isfinite(d[k]) and d[k]<=tol for k,tol in GATES.items() if k!='algebraic_relative')
    if not arm.startswith('ls_'):extra['solver_checks_pass']=bool(d['algebraic_relative']<=1e-8)
    # Preserve the literal original qualification separately; LS uses a distinct solver check.
    literal=all(np.isfinite(d[k]) and d[k]<=tol for k,tol in GATES.items())
    original_residual=d.pop('algebraic_relative');d.pop('qualified',None)
    out=dict(budget=row['budget'],seed=row['seed'],arm=arm,**d,**extra,
      original_equation_relative_residual=original_residual,
      literal_v1_thresholds_pass=bool(literal),physical_screen_pass=bool(physical),
      dense_flux_jump_relative=dense,dense_flux_jump_exact_reference_relative=dense_ref,
      dense_flux_screen_pass=bool(dense<=C.FLUX_JUMP_TOL),
      diagnostic_screen_pass=bool(physical and extra['solver_checks_pass'] and dense<=C.FLUX_JUMP_TOL),
      assembly_and_solve_seconds=elapsed,
      timing_note='Exploratory timing includes a reference square factorization for every arm; not a cost-to-accuracy comparison.')
    write_table(dest/'dense_interface_flux.csv',[dict(x=float(pp[0]),y=float(pp[1]),flux_left=float(a),flux_right=float(bb),exact_flux=float(rr)) for pp,a,bb,rr in zip(p,D0@v,D1@v,ref)])
    np.savez_compressed(dest/'state.npz',nodes=m['nodes'],kinds=m['kinds'],sides=m['sides'],solution=v,rhs=b,
      A_data=m['A'].data,A_indices=m['A'].indices,A_indptr=m['A'].indptr,A_shape=m['A'].shape)
    # For LS the stored A is the reference square operator. Full LS equations
    # are reproducible from the bundled source, nodes, seed and arm; not A v=b.
    return out

def stage07():
    sig=signature();previous=K.OUTPUT_ROOT/'06_archive_diagnosis/completion.json'
    if not previous.exists():raise RuntimeError('Run 06_Archive_Diagnosis_Spyder.py first.')
    done=json.loads(previous.read_text())
    if done['signature']!=sig or done['status']!='complete':raise RuntimeError('Stage 06 must complete with the current package.')
    folder=K.OUTPUT_ROOT/'07_matched_controls';rows=[]
    with threadpool_limits(limits=1):
        for path,row in cases():
            for arm in K.ARMS:
                key=f"N{row['budget']}_s{row['seed']}_{arm}"
                rows.append(run_cached(folder,key,sig,lambda dest,p=path,r=row,a=arm:control_one(p,r,a,dest)))
    write_table(folder/'case_table.csv',rows)
    result=dict(status='complete' if all(r['status']=='complete' for r in rows) else 'completed_with_failures',
      cases=len(rows),completed=sum(r['status']=='complete' for r in rows),signature=sig,
      inference='Training diagnostics only. No original foundation gate or later branch is changed.')
    E.dump(folder/'completion.json',result);print(result,flush=True)

def stage08():
    sig=signature();summary={};all_rows={};folder=K.OUTPUT_ROOT/'08_synthesis';folder.mkdir(parents=True,exist_ok=True)
    for name in ('06_archive_diagnosis','07_matched_controls'):
        p=K.OUTPUT_ROOT/name/'completion.json'
        summary[name]=json.loads(p.read_text()) if p.exists() else dict(status='missing')
        rows=[]
        for rp in sorted((K.OUTPUT_ROOT/name).glob('*/receipt.json')):
            r=json.loads(rp.read_text())
            if r.get('signature')==sig:rows.append(r)
        all_rows[name]=rows
    complete=all(v.get('status')=='complete' and v.get('signature')==sig for v in summary.values())
    controls=all_rows['07_matched_controls'];paired=[];tallies=[]
    for arm in K.ARMS:
        rr=[r for r in controls if r.get('arm')==arm and r['status']=='complete']
        top=[r for r in rr if r['budget']==max(C.BUDGETS)]
        tallies.append(dict(arm=arm,completed=len(rr),expected=9,
          physical_screen_pass=sum(r['physical_screen_pass'] for r in rr),
          diagnostic_screen_pass=sum(r['diagnostic_screen_pass'] for r in rr),
          highest_budget_screen_pass=sum(r['diagnostic_screen_pass'] for r in top),
          highest_budget_expected=3,
          eligible_for_new_validation=bool(complete and len(rr)==9 and len(top)==3 and all(r['diagnostic_screen_pass'] for r in top))))
        for r in rr:
            base=next((b for b in controls if b.get('arm')=='square25' and b.get('budget')==r['budget'] and b.get('seed')==r['seed'] and b['status']=='complete'),None)
            if base:
                paired.append(dict(arm=arm,budget=r['budget'],seed=r['seed'],
                 bulk_error_ratio_to_square25=r['bulk_relative']/base['bulk_relative'],
                 flux_jump_ratio_to_square25=r['flux_jump_relative']/base['flux_jump_relative'],
                 balance_ratio_to_square25=r['balance_scaled']/base['balance_scaled']))
    write_table(folder/'arm_summary.csv',tallies);write_table(folder/'paired_changes.csv',paired)
    candidates=[r['arm'] for r in tallies if r['eligible_for_new_validation']]
    verdict='INCOMPLETE' if not complete else ('CANDIDATES_REQUIRE_NEW_VALIDATION' if candidates else 'FOUNDATION_REMAINS_UNRESOLVED')
    E.dump(folder/'adjudication.json',dict(status=verdict,stages=summary,candidates=candidates,
      original_02_03_authorized=False,original_foundation_pass=False,
      caution='Candidates have been examined on training cases. Freeze any changed operator, rerun independent verification and a fresh foundation before allocation and cost experiments.'))
    lines=['# Foundation recovery review','',f'Status: **{verdict}**','',
      'All six arms are required for complete synthesis. Earlier results are preserved.',
      '', '| Arm | Completed / 9 | Physical screen / 9 | Diagnostic screen / 9 | Highest budget / 3 |',
      '|---|---:|---:|---:|---:|']
    for r in tallies:lines.append(f"| {r['arm']} | {r['completed']} | {r['physical_screen_pass']} | {r['diagnostic_screen_pass']} | {r['highest_budget_screen_pass']} |")
    lines+=['','The diagnostic screen combines the original five physical criteria, a solver check appropriate to the method, and an independent 257-point interface flux check.',
       'Original algebraic residuals and literal v1 threshold attainment are recorded separately for every control.',
       'The LS nodal arm controls for the change of solver and constraints; compare LS flux/PDE/both with it as well as with square25.',
       'Neither training qualification nor a small residual establishes uniform stability or an allocation benefit.',
       '', 'Next: return this entire results ZIP for review. Keep original scripts 02 and 03 on hold.']
    (folder/'REVIEW.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    archive=K.OUTPUT_ROOT.parent/'CGF_Foundation_Recovery_v1_results.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(K.OUTPUT_ROOT.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(K.OUTPUT_ROOT.parent))
    print('\n'+verdict+'\nReturn: '+str(archive),flush=True)

def run(stage):
    K.OUTPUT_ROOT.mkdir(parents=True,exist_ok=True)
    print('CGF foundation recovery | Python',platform.python_version(),'NumPy',np.__version__,'SciPy',scipy.__version__,flush=True)
    print('Outputs:',K.OUTPUT_ROOT,flush=True)
    return {6:stage06,7:stage07,8:stage08}[stage]()
