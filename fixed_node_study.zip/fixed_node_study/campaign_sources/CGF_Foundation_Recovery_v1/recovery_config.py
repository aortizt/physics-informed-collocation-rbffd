"""F5 configuration. Defaults run all nine archived cases, serially."""
from pathlib import Path
HERE = Path(__file__).resolve().parent
EVIDENCE_ROOT = HERE / 'evidence'
OUTPUT_ROOT = HERE / 'CGF_Foundation_Recovery_v1_outputs'
# All arms are fixed before testing; no exact solution is used in assembly.
ARMS = ['square25', 'square37', 'ls_nodal', 'ls_flux', 'ls_pde', 'ls_both']
EXTRA_PDE_PER_INTERIOR = 2
EXTRA_INTERFACE_FACTOR = 4
SOLVER_TOL = 1e-8
CONSTRAINT_TOL = 1e-10
REPLAY_TOL = 1e-8
# Higher resolution is an independent diagnostic, not a changed v1 threshold.
DENSE_INTERFACE_POINTS = 257

