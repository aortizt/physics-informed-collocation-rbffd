# Fixed-node diagnosis, recovery and frozen validation

This folder supplements the earlier allocation, adaptive, adjoint, Robin and SPE10 campaigns. It is a different numerical realization; comparisons are made within matched formulations on identical nodes.

## Reproduce the new manuscript figures and tables

Download the three result ZIPs listed in `analysis_inputs/README.md`, put them in `analysis_inputs/`, and run `regenerate_new_results.py` using F5 in Spyder. No command-line arguments are needed. This is postprocessing only and does not run new PDE experiments. It produces four case-level CSVs, three LaTeX table fragments and Figures 15–16.

The included figures/ folder also carries Figures 1–14 from the earlier manuscript so that the full paper compiles. Their original postprocessing and data are in the earlier repository/archives.

## Reproduce the calculations if needed

`campaign_sources/` contains the foundation implementation, the recovery package (scripts 06–08) and the frozen-validation package (09–12). Preserve each package's directory and evidence/ subdirectory. Read its original protocol before running it. The historical instructions are retained for reproducibility; no further run is required to complete the present paper. The bounded-extension subset retains its original configuration, which may need local path adjustment when reproducing that earliest stage.

The published tests comprise nine original foundation states, 54 recovery/control records, 36 fresh-foundation cases and 48 reserved-transfer cases. Diagnosis reuses the original states; repeated baselines, verification replays, budgets and related loads are not independent replications. Each LS oversampling candidate qualifies in 3/3 fresh highest-budget vertical cases, 6/6 lower-contrast oblique cases, and 0/6 harder oblique cases. All outcomes, including failures, are retained.

No new GHG superiority, general LS stability, production efficiency or LS-adjoint claim follows from these runs. The old sensitivity/cost stages 02/03 are not part of the new evidence.

## Compile the paper

Run `latexmk -pdf CGF_Paper_I_MATCOM_v3p6.tex` here, or pdflatex twice. Keep figures/ and tables/ alongside the source. The author-identified paper is a transfer-preparation copy; the review-anonymity policy and final version-specific data/code DOIs must be settled before submission.
