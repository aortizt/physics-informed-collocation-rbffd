"""Reproduce the new manuscript tables and figures from the supplied results.
Run directly or with F5. This performs postprocessing only; no new PDE runs.
"""
from pathlib import Path
import csv,json,zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent

def rows(archive,branch):
    with zipfile.ZipFile(ROOT/'analysis_inputs'/archive) as z:
        out=[json.loads(z.read(n)) for n in z.namelist() if '/'+branch+'/' in n and n.endswith('/receipt.json')]
    assert out and all(r['status']=='complete' for r in out)
    return out

def save_csv(name,rr):
    keys=sorted(set().union(*(r.keys() for r in rr)))
    with open(ROOT/'data'/name,'w',newline='') as f:
        w=csv.DictWriter(f,keys);w.writeheader()
        for r in rr:w.writerow({k:json.dumps(v) if isinstance(v,(dict,list)) else v for k,v in r.items()})

def main():
    for sub in ['data','tables','figures']:(ROOT/sub).mkdir(exist_ok=True)
    diagnosis=rows('CGF_Foundation_Recovery_v1_results.zip','06_archive_diagnosis')
    recovery=rows('CGF_Foundation_Recovery_v1_results.zip','07_matched_controls')
    foundation=rows('CGF_Frozen_Validation_v1_results.zip','10_fresh_foundation')
    transfer=rows('CGF_Frozen_Validation_v1_results.zip','11_reserved_transfer')
    assert (len(diagnosis),len(recovery),len(foundation),len(transfer))==(9,54,36,48)
    for name,rr in [('diagnosis.csv',diagnosis),('recovery.csv',recovery),('fresh_foundation.csv',foundation),('transfer.csv',transfer)]:save_csv(name,rr)
    names={'square25':'Square-25','square37':'Square-37','ls_nodal':'Nodal LS','ls_flux':'Flux LS','ls_pde':'PDE LS','ls_both':'PDE+flux LS'}
    lines=[]
    for arm,label in names.items():
        rr=[r for r in recovery if r['arm']==arm];top=[r for r in rr if r['budget']==480]
        lines.append(f"{label} & {sum(r['physical_screen_pass'] for r in rr)}/9 & {sum(r['diagnostic_screen_pass'] for r in rr)}/9 & {sum(r['diagnostic_screen_pass'] for r in top)}/3 \\")
    (ROOT/'tables/recovery_rows.tex').write_text('\n'.join(x+'\\' for x in lines)+'\n')
    lines=[];fluxlines=[]
    for arm in ['square25','ls_flux','ls_pde','ls_both']:
        ff=[r for r in foundation if r['arm']==arm]
        top=[r for r in ff if r['budget']==480]
        lo=[r for r in transfer if r['arm']==arm and r['case']=='oblique_low_contrast']
        hi=[r for r in transfer if r['arm']==arm and r['case']=='oblique_holdout']
        lines.append(f"{names[arm]} & {sum(r['qualified'] for r in ff)}/9 & {sum(r['qualified'] for r in top)}/3 & {sum(r['qualified'] for r in lo)}/6 & {sum(r['qualified'] for r in hi)}/6 \\")
        fluxlines.append(f"{names[arm]} & {100*min(r['flux_jump_relative'] for r in lo):.2f}--{100*max(r['flux_jump_relative'] for r in lo):.2f} & {100*min(r['flux_jump_relative'] for r in hi):.2f}--{100*max(r['flux_jump_relative'] for r in hi):.2f} \\")
    (ROOT/'tables/validation_rows.tex').write_text('\n'.join(x+'\\' for x in lines)+'\n')
    (ROOT/'tables/flux_rows.tex').write_text('\n'.join(x+'\\' for x in fluxlines)+'\n')
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'savefig.bbox':'tight'})
    rr=sorted([r for r in diagnosis if r['budget']==480],key=lambda r:r['seed'])
    fig,ax=plt.subplots(1,2,figsize=(10.2,3.7),layout='constrained')
    x=np.arange(3);cols=['#0072B2','#D55E00','#333333']
    for i,(key,label) in enumerate([('reconstruction_inf','Exact-nodal reconstruction'),('consistency_response_inf','Propagated consistency'),('field_error_inf','Total field error')]):
        ax[0].bar(x+(i-1)*.24,[r[key] for r in rr],width=.23,label=label,color=cols[i])
    ax[0].set_yscale('log');ax[0].set_ylim(7e-5,.4);ax[0].set_ylabel('Field error, sampled infinity norm')
    ax[0].set_title('(a) Field decomposition');ax[0].set_xticks(x,[r['seed'] for r in rr]);ax[0].set_xlabel('Seed')
    ax[0].legend(fontsize=8,loc='upper left',frameon=False)
    for i,(key,label) in enumerate([('flux_reconstruction_exact_reference_relative','Exact-nodal jump'),('flux_propagation_exact_reference_relative','Propagated contribution'),('flux_jump_exact_reference_relative','Computed jump')]):
        ax[1].bar(x+(i-1)*.24,[100*r[key] for r in rr],width=.23,label=label,color=cols[i])
    ax[1].set_ylim(0,54);ax[1].set_ylabel('Relative conormal-flux RMS (%)');ax[1].set_title('(b) Common exact-flux normalization')
    ax[1].set_xticks(x,[r['seed'] for r in rr]);ax[1].set_xlabel('Seed');ax[1].legend(fontsize=8,frameon=False)
    fig.savefig(ROOT/'figures/fig15_fixed_node_decomposition.pdf');fig.savefig(ROOT/'figures/fig15_fixed_node_decomposition.png',dpi=160);plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(10.2,3.6),layout='constrained',sharey=True)
    groups=[('Fresh vertical, contrast 20',[r for r in foundation if r['budget']==480]),('Oblique, contrast 5',[r for r in transfer if r['case']=='oblique_low_contrast']),('Oblique, contrast 50',[r for r in transfer if r['case']=='oblique_holdout'])]
    arms=['square25','ls_flux','ls_pde','ls_both'];cols=['#555555','#0072B2','#009E73','#CC79A7']
    for ax,(title,rr) in zip(axes,groups):
        for i,arm in enumerate(arms):
            cases=sorted([r for r in rr if r['arm']==arm],key=lambda r:(r['seed'],r['load']))
            for offset,r in zip(np.linspace(-.14,.14,len(cases)),cases):
                ax.scatter(i+offset,100*r['flux_jump_relative'],c=cols[i],marker='o' if r['load']==0 else '^',s=30,edgecolors='white',linewidths=.3,zorder=3)
        ax.axhline(5,color='#B2182B',ls='--',lw=1);ax.set_yscale('log');ax.set_ylim(.15,500)
        ax.set_xticks(range(4),['Square','Flux\nLS','PDE\nLS','Both\nLS']);ax.set_title(title,fontsize=10);ax.grid(axis='y',alpha=.15)
    axes[0].set_ylabel('Interface flux jump (%)')
    axes[0].text(.03,.96,'Dashed line: 5% threshold',transform=axes[0].transAxes,va='top',fontsize=8)
    fig.savefig(ROOT/'figures/fig16_frozen_flux_validation.pdf');fig.savefig(ROOT/'figures/fig16_frozen_flux_validation.png',dpi=160);plt.close(fig)
    print('Reproduced four CSVs, three table fragments, and two figures from 147 case records.')

if __name__=='__main__':main()
