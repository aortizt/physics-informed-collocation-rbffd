# Inputs from the data deposit

Place these three unchanged files in this directory before running `../regenerate_new_results.py`:

- CGF_Original_Foundation_results.zip
- CGF_Foundation_Recovery_v1_results.zip
- CGF_Frozen_Validation_v1_results.zip

Obtain them from the data archive version associated with the manuscript. The data archive concept DOI is https://doi.org/10.5281/zenodo.22850116. Before the new version is published, the three files are supplied in the companion transfer package under Zenodo_additions/. The earlier public version does not contain them.

The first archive is a documented subset (foundation and verification) of the bounded-extension results. It excludes the unrelated project-file search. The other two are the supplied result ZIPs without modification. Large result archives are held in Zenodo; this source tree retains required recovery reference evidence separately under campaign_sources/.
